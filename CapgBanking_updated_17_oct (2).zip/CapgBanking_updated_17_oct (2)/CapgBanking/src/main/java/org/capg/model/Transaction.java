package org.capg.model;

import java.time.LocalDate;

public class Transaction {
	private int transactionId;
	private String transactionType;
	private LocalDate transactionDate;
	private int fromAccount;
	private int toAccount;
	private double amount;
	private String description;
	
	private int customerId;

	
	public Transaction(int transactionId, LocalDate transactionDate, double amount, String description,
			String transactionType,int customerId) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.description = description;
		this.transactionType = transactionType;
		this.customerId=customerId;
	}
	
	
	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public Transaction() {
		
	}
	
	public Transaction(int transactionId, String transactionType, LocalDate localDate, int fromAccount,
			int toAccount, double amount, String description) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = localDate;
		this.fromAccount = fromAccount;
		this.toAccount =toAccount;
		this.amount = amount;
		this.description = description;
		this.transactionType = transactionType;
	}
	public Transaction(int int1, String string, LocalDate of, int int2, int int3, double double1, String string2,
			int int4) {
		this.transactionId = int1;
		this.transactionDate = of;
		this.fromAccount = int2;
		this.toAccount =int3;
		this.amount = double1;
		this.description = string2;
		this.transactionType = string;
		this.customerId=int4;
	}


	public long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public int getFromAccount() {
		return fromAccount;
	}
	public void setFromAccount(int fromAccount) {
		this.fromAccount = fromAccount;
	}
	public int getToAccount() {
		return toAccount;
	}
	public void setToAccount(int toAccount) {
		this.toAccount = toAccount;
	}
	
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType="+transactionType + ", transactionDate=" + transactionDate + ", fromAccount="
				+ fromAccount + ", toAccount=" + toAccount + ", amount=" + amount + ", description=" + description+"]";
	}


	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	


	
}
