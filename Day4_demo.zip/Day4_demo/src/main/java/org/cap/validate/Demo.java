package org.cap.validate;

public class Demo {

	public int ohk=123;
	public static int ucant=12;
	
	public static void main2() {
		// TODO Auto-generated method stub
		System.out.println("Im Static");
	}

	public void main1() {
		// TODO Auto-generated method stub
		System.out.println("Im not Static");
	}
}
