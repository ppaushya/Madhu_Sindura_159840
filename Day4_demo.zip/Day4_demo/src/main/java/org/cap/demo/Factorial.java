package org.cap.demo;

import java.util.Scanner;

public class Factorial {

	int x;
	Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Factorial obj=new Factorial();

		System.out.println("The input should be between 1 & 18\nEnter the number: ");

		obj.x=obj.sc.nextInt();
		
		System.out.println("Factorial of "+obj.x+" is: "+obj.FirstFactorial(obj.x));
	}

	public int FirstFactorial(int x) {
		// TODO Auto-generated method stub
		int product=1;
		for(int i=1;i<x;i++)
			product*=i;
		return product;
	}

}
