package org.cap.demo;

import java.util.Arrays;

public class TestClass {

	static int a[]= {12,45,87,23,45,0};
	static String a2[]= {"Mad","mad","Prornam","Niha"};
	
	public static void printData(int...x) {
		for(int value: x) {
			System.out.print(value+" ");
		}
	}
	
	public static void printData(String...x) {
		for(String value: x) {
			System.out.print(value+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printData(a);
		
		System.out.println("\n");
		Arrays.sort(a);
		printData(a);
		
		System.out.println("\n");
		Arrays.sort(a2);
		printData(a2);
		
		System.out.println("\n");
		int[] x=Arrays.copyOf(a, 3);
		printData(x);
		
		System.out.println("\n");
		System.out.println(a);
		System.out.println(x);
		
		System.out.println("\n");
		int[] y=Arrays.copyOfRange(a,3,a.length);
		printData(y);
		
		System.out.println("\n");
		int result=Arrays.binarySearch(a,12);
		System.out.println(result);
		
	}

}
