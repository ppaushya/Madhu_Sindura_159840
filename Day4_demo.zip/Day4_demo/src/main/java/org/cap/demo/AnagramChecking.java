package org.cap.demo;

import java.util.Scanner;

public class AnagramChecking {

	public void anagram1(String str1,String str2) {
		char[] arr1=new char[str1.length()];
		char[] arr2=new char[str2.length()];
		int j=0;
		for(int i=0;i<str1.length();i++,j++)
		{
			if(str1.charAt(i)==' ') {
				j--;
				continue;
			}
				
			else
			arr1[j]=str1.charAt(i);
		}
		int j1=0;
		for(int i=0;i<str2.length();j1++,i++)
		{
			if(str2.charAt(i)==' ') {
				j1--;
				continue;
			}
			else
			arr2[j1]=str2.charAt(i);
		}
		if(j==j1) {
			
			char temp;
			for(int i=0;i<j;i++)
			{
				for(int k=i+1;k<j;k++)
				{
					if(arr1[i]>arr1[k])
					{
						temp=arr1[i];
						arr1[i]=arr1[k];
						arr1[k]=temp;
					}
				}
			}
			for(int i=0;i<j1;i++)
			{
				for(int k=i+1;k<j1;k++)
				{
					if(arr2[i]>arr2[k])
					{
						temp=arr2[i];
						arr2[i]=arr2[k];
						arr2[k]=temp;
					}
				}
			}
			int i;
			for(i=0;i<j;i++)
			{
				if(arr1[i]!=arr2[i]) {
					System.out.println("..not an anagram");
					break;
				} 
				
			}
			if(i==j)
				System.out.println("anagram");
		}
		else
			System.out.println("not anagram");
			
	}

		public static void main(String[] args) {
		AnagramChecking obj=new AnagramChecking();
		Scanner s=new Scanner(System.in);
		String str1,str2;
		System.out.println("Enter a string");
		str1=s.nextLine();
		System.out.println("Enter another string");
		str2=s.nextLine();
		s.close();
		obj.anagram1(str1,str2);

		}

}
