package org.cap.demo;

import java.util.Scanner;

public class ReversingTheString {

	Scanner sc=new Scanner(System.in);
	String myStr;
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReversingTheString obj=new ReversingTheString();
		
		obj.myStr=obj.sc.nextLine();
		obj.reversing(obj.myStr);
	}
	
	public void reversing(String str) {
		char[] ch=new char[str.length()];
		char temp;int x=ch.length;
		for(int i=0;i<str.length();i++)
			ch[i]=str.charAt(i);
		
		for(int i=0;i<ch.length/2;i++){
			temp=ch[i];
			ch[i]=ch[x-i-1];
			ch[x-i-1]=temp;
		}
			
		for(int i=0;i<ch.length;i++)
			System.out.print(ch[i]);
	}

}
