package org.cap.demo;

import java.util.Scanner;

public class PrimeFractions {

	int x;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrimeFractions obj=new PrimeFractions();
		Scanner sc=new Scanner(System.in);
		
		obj.x=sc.nextInt();
		obj.getPrimeFractions(obj.x);
		
		sc.close();
	}

	public void getPrimeFractions(int x) {
		// TODO Auto-generated method stub
		int a=x;
		System.out.print("{");
		for(int i=2;i<a;) {
			if(x%i==0) { 
				x/=i;
				if(x<=2) System.out.print(i);
				else System.out.print(i+",");
				i=2;
			}
			else i++;
		}
		System.out.print("}");
	}

}
