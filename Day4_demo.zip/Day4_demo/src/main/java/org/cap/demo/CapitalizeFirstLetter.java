package org.cap.demo;

import java.util.Scanner;

public class CapitalizeFirstLetter {

	Scanner sc=new Scanner(System.in);
	String str;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CapitalizeFirstLetter obj=new CapitalizeFirstLetter();
		
		obj.str=obj.sc.nextLine();
		obj.LetterCapitalize();
	}

	public void LetterCapitalize() {
		char[] ch=new char[str.length()];
		for(int i=0;i<str.length();i++)
			ch[i]=str.charAt(i);
		
		for(int i=0;i<ch.length;i++){
			if(ch[i]==' ' )ch[i+1]=(char) (ch[i+1]-32);
			else if(i==0)ch[i]=(char) (ch[i]-32);
		}
		for(int i=0;i<ch.length;i++)
			System.out.print(ch[i]);
	}

}
