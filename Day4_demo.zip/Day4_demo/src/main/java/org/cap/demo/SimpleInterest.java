package org.cap.demo;

public class SimpleInterest {

	int p,y,i;
	
	public SimpleInterest() {
		// TODO Auto-generated constructor stub
		p=2000;y=3;i=5;
	}

	public SimpleInterest(int p,int y,int i) {
		// TODO Auto-generated constructor stub
		this.p=p;this.y=3;this.i=5;
	}
	
	public SimpleInterest(int y,int i) {
		// TODO Auto-generated constructor stub
		p=2000;this.y=3;this.i=5;
	}
	
	public SimpleInterest(int i) {
		// TODO Auto-generated constructor stub
		p=2000;y=3;this.i=5;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest si1=new SimpleInterest();
		si1.getValue();
		SimpleInterest si2=new SimpleInterest(2000,3,5);
		si2.getValue();
		SimpleInterest si3=new SimpleInterest(3,5);
		si3.getValue();
		SimpleInterest si4=new SimpleInterest(5);
		si4.getValue();si4.main();
		
		for(String i:args) System.out.println("\n\n"+i);
	}
	
	public void main() {
		System.out.println("LOL");
	}

	public void getValue() {
		// TODO Auto-generated method stub
		System.out.println(p*i*y/100+"\n");
	}

}
