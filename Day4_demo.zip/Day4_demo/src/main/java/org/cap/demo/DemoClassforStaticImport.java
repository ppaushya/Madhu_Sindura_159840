package org.cap.demo;

import static org.cap.validate.Demo.*;

import org.cap.validate.Demo;

public class DemoClassforStaticImport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo obj=new Demo();
		main2();
		obj.main1();
		System.out.println(obj.ohk);
		System.out.println(ucant);
	}

}
