package org.cap.demo;

import java.util.Scanner;

public class Product {

	Scanner sc=new Scanner(System.in);
	int productId;
	String productName;
	float price;
	int qty;
	
	public Product() {
		System.out.println("DEFAULT CONSTRUCTOR");
	}
	
	public Product(int x) {
		System.out.println("OVER LOADED CONSTRUCTOR");
		productId=x;
		productName=sc.nextLine();
		price=sc.nextFloat();
		qty=sc.nextInt();
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price
				+ ", qty=" + qty + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Product pr=new Product();
		System.out.println(pr);
		Product pr1=new Product(1);
		System.out.println(pr1+"\n");
		printData(pr1);
	}

	private static void printData(Product x) {
		// TODO Auto-generated method stub
		System.out.println("Name: "+x.productName);
	}

}
