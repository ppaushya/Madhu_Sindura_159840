package org.cap.demo;

import java.util.Scanner;

public class FindingTheLongestNumber {

	Scanner sc=new Scanner(System.in);
	String myStr;
			
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FindingTheLongestNumber obj=new FindingTheLongestNumber();
		
		obj.myStr=obj.sc.nextLine();
		obj.LongestWord(obj.myStr);
	}
	
	public void LongestWord(String str) {
		char[] ch=new char[str.length()];
		short temp=0,temp2=0,x=0,a1=0;
		for(int i=0;i<str.length();i++)
			ch[i]=str.charAt(i);
		
		for(short i=0;i<ch.length;i++) {
			if(i==0 || ch[i]!=' '&&ch[i-1]==' ')x=i;
			if(ch[i]!=' ') {temp++;}
			if(ch[i]==' '||i==ch.length-1) {if(temp2<=temp)temp2=i;a1=x;temp=0;}
		}

		System.out.print("Longets word is: ");
		for(int i=a1;i<temp2;i++)
			System.out.print(ch[i]);
	}

}
