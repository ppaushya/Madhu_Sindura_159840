package org.cap.demo;

import java.util.Scanner;

public class LetterReplacing {

	Scanner sc=new Scanner(System.in);
	String str;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LetterReplacing obj=new LetterReplacing();
		
		obj.str=obj.sc.nextLine();
		obj.LetterChanges();
	}

	public void LetterChanges() {
		char[] ch=new char[str.length()];
		for(int i=0;i<str.length();i++)
			ch[i]=str.charAt(i);
		
		for(int i=0;i<ch.length;i++){
			ch[i]=(char) (97+25-(ch[i]-97));
			if(ch[i]=='a' ||ch[i]=='o' ||ch[i]=='e' ||ch[i]=='i' ||ch[i]=='u')ch[i]=(char) (ch[i]-32);;
		}
			
		for(int i=0;i<ch.length;i++)
			System.out.print(ch[i]);
	}
}
