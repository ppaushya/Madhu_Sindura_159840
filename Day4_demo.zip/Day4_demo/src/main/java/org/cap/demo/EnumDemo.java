package org.cap.demo;

enum Weekdays{
	SUN(1),MON(2),TUE(3),WED(4),THU(5),FRI(6),SAT(7);
	
	int value;
	Weekdays(int value) {
		this.value=value;
	}
	
	public int getValue() {
		return this.value;
	}
}

public class EnumDemo {

	int holidayId;
	String holidayType;
	Weekdays day;
	
	
	public int getValue(Weekdays x) {
		return x.value;
	}
	
	public void getHoliday() {
		holidayType="Dance";
		holidayId=11;
		day=Weekdays.FRI;
	}

	public void printHoliday() {
		System.out.print(holidayId+ " ");
		System.out.print(holidayType+ " ");
		System.out.println(day+" "+day.value+" "+getValue(day)+" "+day.getValue());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EnumDemo obj=new EnumDemo();
		obj.getHoliday();
		obj.printHoliday();
	}

}
