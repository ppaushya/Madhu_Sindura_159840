package org.mno.model;

public enum AccountType {
	
	SAVINGS,CURRENT,FD,RD;

}