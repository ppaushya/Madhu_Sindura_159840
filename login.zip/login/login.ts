export class Login
{
    userName:string;
    userPassword:string;

    constructor(userName,userPassword)
    {
        this.userName=userName;
        this.userPassword=userPassword;
    }
    
}