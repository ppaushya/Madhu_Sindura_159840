package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotService")
public class PilotServiceImpl implements IPilotService{

	@Autowired
	private IPilotDao pilotDao;
	
	@Override
	public List<Pilot> getAllPilots() {
		return pilotDao.getAllPilots();
	}

	@Override
	public Pilot find(int pilotId) {
		return pilotDao.find(pilotId);
	}

	@Override
	public List<Pilot> updateCustomers(Pilot pilot) {
		return pilotDao.updateCustomers(pilot);
	}

	@Override
	public List<Pilot> deleteCustomer(Integer pilotId) {
		return null;
	}

}
