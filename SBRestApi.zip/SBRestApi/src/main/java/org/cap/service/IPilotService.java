package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotService {
	public List<Pilot> getAllPilots();

	public Pilot find(int pilotId);

	public List<Pilot> updateCustomers(Pilot pilot);

	public List<Pilot> deleteCustomer(Integer pilotId);
}
