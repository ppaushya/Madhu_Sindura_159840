package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;

public interface IPilotDao {
	
	public List<Pilot> getAllPilots();

	public Pilot find(int pilotId);

	public List<Pilot> updateCustomers(Pilot pilot);

}
