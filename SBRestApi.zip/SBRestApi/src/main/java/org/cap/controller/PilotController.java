package org.cap.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.cap.model.Customer;
import org.cap.model.Pilot;
import org.cap.service.IPilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class PilotController {

	@Autowired
	private IPilotService pilotService;
	
	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		
		List<Pilot> pilots=pilotService.getAllPilots();
		
		if(pilots.isEmpty())
			return new ResponseEntity("Sorry! Pilots Not available!",
					HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
	
	
	@GetMapping("/pilots/{pilotId}")
	public ResponseEntity<Pilot> findPilot(@PathVariable("pilotId") int pilotId){
		Pilot pilot= pilotService.find(pilotId);
		if(pilot==null)
			return new ResponseEntity("Sorry! Customer list not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Pilot>(pilot, HttpStatus.OK);
	}
	
	@PutMapping("/pilots")
	public ResponseEntity<List<Pilot>> updateCustomers(@RequestBody Pilot pilot){
		List<Pilot> pilots= pilotService.updateCustomers(pilot);
		System.out.println(pilots);
		if(pilots.isEmpty())
			return new ResponseEntity("insertion failed", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@DeleteMapping(value="/pilots/{pilotId}")
	public ResponseEntity<List<Pilot>>deletCustomer(
			@PathVariable("pilotId")Integer pilotId){
		List<Pilot> pilots= pilotService.deleteCustomer(pilotId);
		
		if(pilots==null)
			return new ResponseEntity("Sorry! Customer Id not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}

}
