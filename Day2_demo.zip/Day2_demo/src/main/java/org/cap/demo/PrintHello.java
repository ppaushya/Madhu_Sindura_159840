package org.cap.demo;

import java.util.Scanner;

public class PrintHello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String x=sc.next();
		
		//System.out.println(x.length());
		for(int i=0;i<x.length();i++) {
			for(int j=0;j<x.length();j++) {
				if(j<=i) System.out.print(x.charAt(j));
			}
			System.out.println();
		}

		sc.close();
	}

}
