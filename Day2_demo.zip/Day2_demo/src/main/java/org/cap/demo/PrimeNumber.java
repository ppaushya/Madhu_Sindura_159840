package org.cap.demo;

import java.util.Scanner;

public class PrimeNumber {

	public static boolean checkPrimeNumber(int x) {
		int count=0;
		for(int i=2;i<squareRoot(x);i++) {
			if(x%i==0) return false;
			else count++;
		}
		if(count!=0) return true;
		return false;
	}
	
	public static int squareRoot(int x) {
		return (int) Math.sqrt(x);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Number: ");
		int input=sc.nextInt();
		
		for(int i=2;i<input;i++) {
			if(checkPrimeNumber(i)) System.out.println(i+" ");
		}
		sc.close();
	}

}
