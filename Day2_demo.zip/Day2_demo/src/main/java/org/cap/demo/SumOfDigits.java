package org.cap.demo;

import java.util.Scanner;

public class SumOfDigits {
	
	public int findSum(int x) {
		int sum=0;
		while(x!=0) {
			sum+=(x%10);x/=10;
		}
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		int x=sc.nextInt();
		SumOfDigits obj=new SumOfDigits();
		
		System.out.println("Sum of the digits of the number: "+obj.findSum(x));
		
		sc.close();
	}

}
