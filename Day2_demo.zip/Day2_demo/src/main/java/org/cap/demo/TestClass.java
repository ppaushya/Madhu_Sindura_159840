package org.cap.demo;

import java.util.Scanner;

public class TestClass {

	public void testIf(int number) {
		if(number > 0) { 
			System.out.println(number+"\nThe given number is positive");
			if(number%2==0) System.out.println("The given number is divisible by 2");
			else System.out.println("The given number is not divisible by 2");
		}else if(number < 0) System.out.println(number+"\nThe given number is negative");
		else System.out.println(number+"\nThe given number is zero");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestClass obj=new TestClass();
		Scanner sc=new Scanner(System.in);
		obj.testIf(sc.nextInt());
		sc.close();
	}

}
