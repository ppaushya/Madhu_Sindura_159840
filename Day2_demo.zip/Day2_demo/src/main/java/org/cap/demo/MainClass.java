package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1,sum=0,count=0,count1=0;
		do { 
			if(num%2==0) { 
				//if(count1%6==0 && count==0) {System.out.print(num+" ");}
				if(count1%6==0)System.out.print(num+" ");
				else System.out.print(" * ");
				sum+=num;
				count++;count1++;
			}
			if(count==5) {System.out.println("");count=0;}
			num++;
		}while(num<=100);
		System.out.println("\\\\\\\\"+sum+" ");
	}
}
