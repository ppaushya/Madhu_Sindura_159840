package org.cap.demo;

import java.util.Scanner;

public class OddEvenSets {

	public void createSets(int x) {
		//int count=0;
		for(int i=1;i<=x;i+=6) {
			for(int j=0+i;j<=5+i;j++) {
				if(j>x) System.exit(0);
				if(j%2!=0)System.out.print(j+" ");
			}
			//if(count!=0) break;
			for(int j=0+i;j<=5+i;j++) {
				if(j>x) break;
				if(j%2==0)System.out.print(j+" ");
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		OddEvenSets obj=new OddEvenSets();
		
		System.out.println("Enter the number: ");
		obj.createSets(sc.nextInt());
		
		sc.close();
	}

}
