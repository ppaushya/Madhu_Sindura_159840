package org.cap.demo;

import java.util.Scanner;

public class ArmstrongNumber {

	public static boolean isArmstrongNumber(int x) {
		int sum=0,a=x;
		while(x!=0) {
			sum+=Math.pow(x%10,3);x/=10;
		}
		if(sum==a)return true;
		else return false;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the number: ");
		int input=sc.nextInt();
		
		for(int i=3;i<=input;i++) {
			if(isArmstrongNumber(i)) System.out.print(i+" ");
		}
		
		sc.close();
	}

}
