package org.cap.demo;

import java.util.Scanner;

public class SwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		int num=sc.nextInt();
		switch(num) {
			case 1:{ System.out.println("One");break;}
			case 2:{ System.out.println("Two");break;}
			case 3:{ System.out.println("Three");break;}
			case 4:{ System.out.println("Four");break;}
			case 5:{ System.out.println("Five");break;}
			case 6:{ System.out.println("Six");break;}
			case 7:{ System.out.println("Seven");break;}
			case 8:{ System.out.println("Eight");break;}
			case 9:{ System.out.println("Nine");break;}
			case 10:{ System.out.println("Ten");break;}
			case 100:
			case 1000: 
			case 10000:{ System.out.println("Divisible by 100");break;}
			default: System.out.println(">Ten But not divisible by 100");
		}
		sc.nextLine();
		
		String str=sc.nextLine();
		switch(str) {
			case "One":{ System.out.println("1");break;}
			case "Two":{ System.out.println("2");break;}
			case "Three":{ System.out.println("3");break;}
			case "Four":{ System.out.println("4");break;}
			case "Five":{ System.out.println("5");break;}
			default: System.out.println(">10");
		}
		
		String tof=sc.next();
		switch(tof) {
			case "T":
			case "t":{ System.out.println("True");break;}
			case "F":
			case "f":{ System.out.println("False");break;}
			default: System.out.println("Enter T/F or t/f");
		}
		sc.close();
	}

}
