package org.cap.demo;

import java.util.Scanner;

public class AllPossibilities {

	/*public static int sumCall(int x) {
		System.out.print("1");
		if(x==1) return 1;
		System.out.print("+");
		return sumCall(x-1)+1;
	}*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Target Value: ");
		int input=sc.nextInt();
		System.out.println("Output: ");
		
//			sum=sumCall(input);
		//System.out.println("\nOutput: "+sumCall(input));
		sc.close();
	}

}
