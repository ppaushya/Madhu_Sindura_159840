package org.cap.demo;

import java.util.Scanner;

public class MinimumElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner sc=new Scanner(System.in);
			
			System.out.println("Target Value: ");
			int input=sc.nextInt();
			System.out.println("Output: ");
			
	}

}
