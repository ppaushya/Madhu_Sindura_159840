package org.cap.demo;

public class Pattern_3 {
	
	public static int fact(int num) {
		int x=1;
		for(int i=1;i<=num;i++) x*=i;
		return x;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=4;i++) {
			for(int j=1;j<=4;j++) {
				if(j>=i) { System.out.print("*\t\t");}
				else {System.out.print(" \t");}
			}
			System.out.println("\n");
		}
		for(int i=0;i<4;i++) {
			for(int j=1;j<=3-i;j++) {
		            System.out.print(" \t");
		         }
		    for(int j=0;j<=i;j++){
				System.out.print(fact(i)/(fact(i-j)*fact(j))+"\t\t");
			}
			System.out.println("\n");
		}
	}

}
