package org.cap.demo;

import java.util.Scanner;

public class Product {
	
	String productName;
	int productId,quantity;
	float price,discount,tax;
	//String choice;
	int choice=1;
	
	public boolean getProductDetails() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Product Name ");
		productName=sc.nextLine();
		System.out.println("Enter Product Id ");
		productId=sc.nextInt();
		System.out.println("Quantity: ");
		quantity=sc.nextInt();
		System.out.println("Price: ");
		price=sc.nextFloat();
		System.out.println("Discount%: ");
		discount=sc.nextFloat();
		if(discount>=90) tax=1;
		else if(discount>=80 && discount<90) tax=12;
		else if(discount>=60 && discount<80) tax=20;
		else if(discount>=50 && discount<60) tax=25;
		else if(discount<50) tax=40;
		else if(discount<0) {sc.close(); return false;}
		sc.close();
		return true;
	}
	
	public float calculateTax() {
		return price*tax/100;
	}
	
	public float calculateDiscount() {
		return price*discount/100;
	}

	public float calculateFinalPrice() {
		return (price+calculateTax()-calculateDiscount())*quantity;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product obj=new Product();
		Scanner scan=new Scanner(System.in);
		do {
			//scan.nextLine();
			if(obj.getProductDetails()) {
				System.out.println("Final Price: "+obj.calculateFinalPrice());
			}else System.out.println("Invalid! Discount cannot be negative");
			System.out.println("Do you want to enter another product");
			obj.choice=scan.nextInt();
		}while(obj.choice==1);
		scan.close();
	}

}
