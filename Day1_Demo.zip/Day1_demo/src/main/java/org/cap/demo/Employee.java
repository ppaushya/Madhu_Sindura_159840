package org.cap.demo;

import java.util.Scanner;

public class Employee {

	int empId;
	String empName;
	int age;
	boolean isPermanent;
	String gender;
	String address;
	
	Scanner sc=new Scanner(System.in);
	
	public void getEmployee() {
		System.out.println("Emp Id: ");
		empId=sc.nextInt();
		System.out.println("Name: ");
		sc.nextLine();
		empName=sc.nextLine();
		System.out.println("Age: ");
		age=sc.nextInt();
		System.out.println("Status: ");
		isPermanent=sc.nextBoolean();
		System.out.println("Gender: ");
		gender=sc.next();
		System.out.println("Addres: ");
		address=sc.next();
	}
	
	
	public void printEmployee() {
		System.out.println("Employee Id "+empId);
		System.out.println("Employee Name "+empName);
		System.out.println("Employee Status "+isPermanent);
		System.out.println("Gender "+gender);
		System.out.println("Address "+address);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.getEmployee();
		emp.printEmployee();
	}

}
