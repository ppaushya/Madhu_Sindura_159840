package org.cap.demo;

import java.util.Scanner;

public class Student {

	String name;
	int marks1,marks2,marks3;
	Scanner sc=new Scanner(System.in);
	
	public void getStudent() {
		System.out.println("Name");
		name=sc.nextLine();
		System.out.println("Marks in sub 1: ");
		marks1=sc.nextInt();
		System.out.println("Marks in sub 2: ");
		marks2=sc.nextInt();
		System.out.println("Marks in sub 3: ");
		marks3=sc.nextInt();
	}
	
	public int findScore() {
		return marks1+marks2+marks3;
	}
	
	public float findAvg() {
		return (findScore())/3;
	}
	
	public void printStudent() {
		System.out.println("Name: "+name);
		System.out.println("Marks in subject 1: "+marks1);
		System.out.println("Marks in subject 2: "+marks2);
		System.out.println("Marks in subject 3: "+marks3);
		System.out.println("Total marks: "+findScore());
		System.out.println("Avg marks: "+findAvg());

	}
	
	public static void main(String[] args) {
		Student student1=new Student();
		student1.getStudent();
		student1.printStudent();
	}

}
