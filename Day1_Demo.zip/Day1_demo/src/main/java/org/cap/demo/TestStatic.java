package org.cap.demo;

public class TestStatic {
	
	String name;
	static String count="1196";
	final float pi=3.14f;

	public void show() {
		System.out.println(name+" Count: "+count);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TestStatic obj=new TestStatic();
		obj.name="Madhu";
		//count=1196;
		obj.show();
		
		System.out.println(obj.name+" "+count+" "+obj.pi);
		
		TestStatic obj2=new TestStatic();
		obj2.name="Sindura";
		//obj2.count=1123;
		obj2.show();
		
		System.out.println(obj2.name+" "+count);
		
	}

}
