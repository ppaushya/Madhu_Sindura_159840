package org.cap.demo;

import java.util.Scanner;

public class SimpleInterest {

	double principle;
	float years;
	float rateOfInterest;
	
	Scanner scanner=new Scanner(System.in);
	
	public void getData() {
		/*principle=4000;
		years=3.3f;
		rateOfInterest=.0665f;*/
		
		System.out.println("Enter P:");
		principle=scanner.nextDouble();
		System.out.println("Enter years:");
		years=scanner.nextFloat();
		System.out.println("Enter rateOfInterest:");
		rateOfInterest=scanner.nextFloat();
	}
	
	public double calculateInterest() {
		return principle*years*rateOfInterest;
	}
	

}
