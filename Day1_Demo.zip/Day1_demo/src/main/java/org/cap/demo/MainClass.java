package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleInterest obj=new SimpleInterest();
		obj.getData();
		//obj.principle=obj.scanner.nextDouble();
		double a=obj.calculateInterest();
		
		System.out.println(a);
	}

}
