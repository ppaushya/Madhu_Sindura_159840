package org.cap.demo;

public class Test {
	//instance variables
	int count;
	char ch;
	boolean flag;
	float pi;
	
	public static void main(String[] args) {
		
		int mynum=00;
		
		//creating a new object
		Test obj=new Test();
		obj.count=25;
		
		System.out.println(obj.count);
		System.out.println(obj.ch);
		System.out.println(obj.flag);
		System.out.println(obj.pi);
		
		System.out.println("mynum= "+mynum);
	}
}
