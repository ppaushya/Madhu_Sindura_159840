package org.cap.service;

import org.cap.exception.AccountNotFoundException;
import org.cap.exception.InsufficientbalanceException;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface IAccountService {

	static int currentBalance = 0;
	public Account createAccount(Customer customer,double balance) throws InsufficientbalanceException;
	public boolean createTransaction(Transaction transaction) throws InsufficientbalanceException, AccountNotFoundException;
}
