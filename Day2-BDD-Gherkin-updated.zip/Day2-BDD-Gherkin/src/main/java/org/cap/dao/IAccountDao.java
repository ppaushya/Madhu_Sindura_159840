package org.cap.dao;

import org.cap.model.Account;
import org.cap.model.Transaction;

public interface IAccountDao {

	public boolean createAccount(Account account);

	public boolean createTransaction(Transaction transaction);
}
