import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-main-header',
  templateUrl: './admin-main-page.component.html',
  styleUrls: ['./admin-main-page.component.css']
})
export class AdminMainPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
