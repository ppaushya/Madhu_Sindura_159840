import { Component, OnInit } from '@angular/core';
import { Inventory } from '../models/Inventory';
import { ByCategoryService } from './by-category.service';
import { Promos } from '../models/Promos';
import { PromoService } from '../promos/promo.service';
import { ProductService } from '../products/product-service.service';
import { AppService } from '../app.service';
@Component({
  selector: 'app-by-category',
  templateUrl: './by-category.component.html',
  styleUrls: ['./by-category.component.css']
})
export class ByCategoryComponent implements OnInit {
  inventory:Inventory[]
  selectedCategory:string;
  categories:string[]=[
      "Health Care","Books","Groceries","Electronics","Automobiles"
  ];
  promos:Promos[]=[];
  constructor(private _byCategoryService: AppService) { }
  
  ngOnInit() {
    this._byCategoryService.getAllPromos().subscribe(promos=>{
      this.promos=promos;
    })
  }
  category1(category:string){
    this.selectedCategory=category;
  }
  promoCode:string
  edit(){
    this._byCategoryService.editByCategory(this.promoCode,this.selectedCategory).subscribe(flag=>{
      if(flag)
        alert("Promo Applied");
      else
        alert("PromoCode Not Applicable!");
    });
  }
}