import { Injectable } from '@angular/core';
import { Inventory } from '../models/Inventory';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Promos } from '../models/Promos';

const headers= new HttpHeaders({ 'Content-Type':'application/json'});

@Injectable({
  providedIn: 'root'
})
export class ByCategoryService {
  private byCategoryurl="";

  inventory: Inventory[];

  constructor(private http: HttpClient) { }
  
  getProductCategory():Observable <string[]> 
  {
    return this.http.get<string[]>(this.byCategoryurl)
  };
  getAllPromos():Observable<Promos[]>{
    return this.http.get<Promos[]>("http://localhost:8085/capstore/api/v1/getAllPromos");
  }
  editByCategory(promoCode:string):Observable<Boolean>{
    return this.http.put<Boolean>("http://localhost:8085/capstore/api/v1/editAllPromos",promoCode);
  }
}



