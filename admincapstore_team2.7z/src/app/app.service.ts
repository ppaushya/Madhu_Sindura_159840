import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ISalesAnalysis } from './business-analysis/ISalesAnalysis';
import { Promos } from './models/Promos';
import { Customer } from './models/Customer';
import { Coupon } from './models/coupon';
import { Merchant } from './models/merchant';
import { Inventory } from './models/Inventory';
import { Shipment } from './models/Shipment';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor(private _http: HttpClient) { }

  //businessAnalysis
  getSalesAnalysis(): Observable<ISalesAnalysis[]> {
    let url = "http://localhost:8086/capstore/api/v1/products/salesAnalysis"
    return this._http.get<ISalesAnalysis[]>(url)
  }

  //byCategory
  getProductCategory(): Observable<string[]> {
    let url = "http://localhost:8086/capstore/api/v1/getCategories"
    return this._http.get<string[]>(url)
  };
  getAllPromos(): Observable<Promos[]> {
    return this._http.get<Promos[]>("http://localhost:8086/capstore/api/v1/getAllPromos");
  }
  editByCategory(promoCode: string, category: string): Observable<Boolean> {
    return this._http.get<Boolean>("http://localhost:8086/capstore/api/v1/editAllPromos/" + promoCode + "/" + category);
  }

  //customer
  getCustomers(): Observable<Customer[]> {
    //console.log(('Customers here!!'+this.http.get<Customer[]>(this.custUrl+'/all')));
    let url = "http://localhost:8086/capstore/api/v1/customers";
    return this._http.get<Customer[]>(url);
  }
  deleteCustomer(customerId: number): Observable<Customer[]> {
    let url = "http://localhost:8086/capstore/api/v1/customers";
    return this._http.delete<Customer[]>(url);
  }

  //generateCoupons
  coupon: Coupon;
  generatecoupon(coupons: Coupon): Observable<Coupon> {
    let url = "";
    return this._http.post<Coupon>(url, coupons, {});
  }
  emailcoupon(coupon: Coupon): Observable<Coupon> {
    let url = "";
    return this._http.post<Coupon>(url + "/" + "emailcoupon", coupon, {})
  }
  setCoupon(coupon: Coupon): void {
    this.coupon = coupon;
  }

  //merchant
  getMerchants(): Observable<Merchant[]> {
    //console.log(('Merchants here!!'+this.http.get<Merchant[]>(this.custUrl+'/all')));
    let url = "http://localhost:8086/capstore/api/v1/merchants/all"
    return this._http.get<Merchant[]>(url);
  }
  deleteMerchant(merchantId: number): Observable<Merchant[]> {
    let url = "http://localhost:8086/capstore/api/v1/merchantReject"
    url = url + '/' + merchantId;
    return this._http.get<Merchant[]>(url);
  }
  verifyMerchant(merchantId: number): Observable<Merchant[]> {
    return this._http.get<Merchant[]>('http://localhost:8086/capstore/api/v1/merchantVerification/' + merchantId);
  }
  inviteMerchant(merchantMailID: string): Observable<boolean> {
    return this._http.post<boolean>("http://localhost:8086/capstore/api/v1/inviteMerchant", merchantMailID);
  }

  //product
  getInventories(): Observable<Inventory[]> {
    //console.log(('Inventories here!!'+this.http.get<Inventory[]>(this.custUrl)));
    let url = "http://localhost:8086/capstore/api/v1/viewInventories"
    return this._http.get<Inventory[]>(url);
  }

  deleteInventory(inventoryId: number): Observable<Inventory[]> {
    let url = "http://localhost:8086/capstore/api/v1/viewInventories"
    url = url + '/' + inventoryId;
    return this._http.delete<Inventory[]>(url);
  }
  editInventory(inventory: Inventory): Observable<Inventory[]> {
    return this._http.put<Inventory[]>('http://localhost:8086/capstore/api/v1/inventory', inventory, {});
  }
  getPromo(promoCode: string): Observable<Promos> {
    return this._http.get<Promos>("http://localhost:8086/capstore/api/v1/getPromo/" + promoCode);
  }

  //promo
  addPromo(promo: Promos): Observable<Boolean> {
    let url = "http://localhost:8086/capstore/api/v1/inventories"
    return this._http.post<Boolean>(url + '/promo', promo);
  }

  //shipment
  private shipmentUrl='http://localhost:8085/capstore/api/v1/shipment/all';
  private shipmentUpdateUrl='http://localhost:8085/capstore/api/v1/updateShipmentDeliveryStatus';
  getShipments(): Observable<Shipment[]> {
    return this._http.get<Shipment[]>(this.shipmentUrl);
  }
  updateShipment(shipmentId: number, status: string): Observable<boolean> {
    return this._http.post<boolean>(
      this.shipmentUpdateUrl + '/' + shipmentId + '/' + status
      , null, {});
  }


}
