package org.cap.exception;

public class InvalidNameException extends Exception {
	public InvalidNameException(String str) {
		super(str);
	}
}
