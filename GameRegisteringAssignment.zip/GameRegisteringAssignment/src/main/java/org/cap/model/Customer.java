package org.cap.model;


/*setCustomerId(Utility.generateId());
customer.setFirstName(Utility.promptName());
customer.setMobileNo(Utility.promptMobileNo());
customer.setDateOfBirth(Utility.promptFees());
customer.setAddress(Utili*/
public class Customer {
	
	private int registrationId;
	private String name;
	private String mobileNo;
	private double fees;
	private int age;
	private double actualFeesPaid;
	
	@Override
	public String toString() {
		return "Customer [registrationId=" + registrationId + ", name=" + name + ", mobileNo=" + mobileNo + ", fees="
				+ fees + ", age=" + age + ", actualFeesPaid=" + actualFeesPaid + "]";
	}
	
	public Customer() {
		super();
	}

	public Customer(int registrationId, String name, String mobileNo, double fees, int age, double actualFeesPaid) {
		super();
		this.registrationId = registrationId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.fees = fees;
		this.age = age;
		this.actualFeesPaid = actualFeesPaid;
	}



	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public double getActualFeesPaid() {
		return actualFeesPaid;
	}

	public void setActualFeesPaid(double actualFeesPaid) {
		this.actualFeesPaid = actualFeesPaid;
	}
	
}
