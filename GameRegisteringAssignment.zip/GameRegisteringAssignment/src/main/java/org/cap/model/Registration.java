package org.cap.model;

public class Registration {

}
