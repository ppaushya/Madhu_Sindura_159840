package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.cap.model.Customer;

public class CustomerDaoImplementation implements ICustomerDao {

	//final static Logger logger;
	
	private Connection getDbConnection() {
		Connection connection=null;;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root" , "India123");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	@Override
	public boolean createCustomer(Customer customer) {
		
		String sql="insert into employee values(?,?,?,?,?)";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1, customer.getRegistrationId());
			statement.setString(2, customer.getName());
			statement.setString(3, customer.getMobileNo());
			statement.setInt(4,customer.getAge());
			int count=statement.executeUpdate();			
			if(count>0)
				System.out.println("Insertion done!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public String generateExitMsg() {
		return "Somewhat done! :D";
	}

}
