package org.cap.ui;

import org.cap.model.Customer;
import org.cap.util.Utility;

public class UserInteraction {

	public Customer getCustomerDetails() {
		Customer customer=new Customer();
		
		customer.setRegistrationId(Utility.generateId());
		customer.setName(Utility.promptName());
		customer.setMobileNo(Utility.promptMobileNo());
		customer.setFees(Utility.promptFees());
		customer.setAge(Utility.promptAge());
		
		return customer;
	}

}
