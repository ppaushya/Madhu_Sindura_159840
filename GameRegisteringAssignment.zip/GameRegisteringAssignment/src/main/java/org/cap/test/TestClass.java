package org.cap.test;

import static org.junit.Assert.*;

import org.cap.dao.ICustomerDao;
import org.cap.exception.InvalidMobileException;
import org.cap.exception.InvalidNameException;
import org.cap.model.Customer;
import org.cap.view.ICustomerService;
import org.junit.Test;


public class TestClass {
	
	@Mock
	private ICustomerDao customerDao;
	
	private ICustomerService customerService;
	
	@Test(expected=InvalidNameException.class)
	public void test_customer_creation() throws InvalidNameException {
		
		MockitoAnnotations.initMocks(this);
		
		Customer customer=new Customer();
		customer.setRegistrationId(100);
		customer.setName("Tom");
		customer.setMobileNo("+91-9638285863");
		
		//dummy Declaration
		Mockito.when(customerDao.createCustomer(customer)).thenReturn(true);
		
		
		//Actual Logic Triggered
		boolean flag=customerService.createCustomer(customer);
		
		
		//verification
		Mockito.verify(customerDao).addAccount(customer);

		assertNotNull(customer);
		assertEquals(13000, customer.getActualFeesPaid()0.0);
		
	}
	
	@Test(expected=InvalidNameException.class)
	public void test_customer_name() throws InvalidNameException {
		Customer customer=new Customer();
		customer.setRegistrationId(100);
		customer.setName("Tom");
		customer.setMobileNo("+91-9638285863");
		customerService.createCustomer(customer);
	}
	
	
	@Test(expected=InvalidMobileException.class)
	public void test_customer_mobileNo() throws InvalidMobileException {
		Customer customer=new Customer();
		customer.setRegistrationId(100);
		customer.setName("Tom");
		customer.setMobileNo("+91-9638285863");
		customerService.createCustomer(customer);		
	}
	
}
