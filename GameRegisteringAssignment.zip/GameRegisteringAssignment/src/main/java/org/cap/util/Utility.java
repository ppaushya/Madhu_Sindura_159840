package org.cap.util;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utility {

	private static int customerId=200;
	
	public static int promptFees() {
		Scanner scanner=new Scanner(System.in);
		int tempFee;
		System.out.print("Enter fee: ");
		while(true) {
			tempFee=scanner.nextInt();
			if(tempFee<100) System.out.println("Minimum fee 500/-");
			else break;
		}
		scanner.close();
		return tempFee;
	}

	public static String promptMobileNo() {
		Scanner scanner=new Scanner(System.in);
		String tempMobileNo;
		System.out.print("Enter mobile no.: ");
		while(true) {
			tempMobileNo=scanner.next();
			Pattern p=Pattern.compile("\\(+91)-[789][0-9]{9}");
			Matcher match=p.matcher(tempMobileNo);
			if(!match.find()) System.out.println("Enter valid mobile no.");
			else break;
		}
		scanner.close();
		return tempMobileNo;
	}

	public static int generateId() {
		return customerId++;
	}

	public static String promptName() {
		Scanner scanner=new Scanner(System.in);
		String tempFirstName;
		System.out.print("Enter name: ");
		while(true) {
			tempFirstName=scanner.next();
			Pattern p=Pattern.compile("[a-zA-Z\\ \\]{3,}");
			Matcher match=p.matcher(tempFirstName);
			if(!match.find()) System.out.println("Enter valid first name");
			else break;
		}
		scanner.close();
		return tempFirstName;
	}

	public static int promptAge() {
		Scanner scanner=new Scanner(System.in);
		int tempAge;
		System.out.print("Enter age: ");
		while(true) {
			tempAge=scanner.nextInt();
			if(tempAge>100 || tempAge<0) System.out.println("Age cannot be negative or >100");
			else break;
		}
		scanner.close();
		return tempAge;
	}

}
