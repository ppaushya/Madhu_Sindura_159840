package org.cap.view;

import org.cap.dao.CustomerDaoImplementation;
import org.cap.dao.ICustomerDao;
import org.cap.exception.InvalidMobileException;
import org.cap.exception.InvalidNameException;
import org.cap.model.Customer;
import org.cap.ui.UserInteraction;

public class CustomerServiceImplementation implements ICustomerService {

	ICustomerDao customerDao=new CustomerDaoImplementation();
	UserInteraction userInteraction = new UserInteraction();
	
	@Override
	public boolean createCustomer(Customer customer) throws InvalidNameException, InvalidMobileException {
		if(!customer.getName().matches("[a-zA-Z]{3,}")) 
			throw new InvalidNameException("Invalid Customer Name!");
		if(!customer.getMobileNo().matches("[789][0-9]{9}"))
			throw new InvalidMobileException("Sorry! Invalid mobile number!");

		if(customerDao.createCustomer(customer)) {
			if(customer.getAge()>0 && customer.getAge()<0) customer.setActualFeesPaid(customer.getFees());
			else if(customer.getAge()>18 && customer.getAge()<=25) customer.setActualFeesPaid(customer.getFees()+customer.getFees()*.1);
			else if(customer.getAge()>25 && customer.getAge()<=50) customer.setActualFeesPaid(customer.getFees()+customer.getFees()*.2);
			else if(customer.getAge()>50) customer.setActualFeesPaid(customer.getFees()+customer.getFees()*.3);
			return true;
		}
		else return false;
	}

	@Override
	public String generateExitMsg() {
		return customerDao.generateExitMsg();
	}

}
