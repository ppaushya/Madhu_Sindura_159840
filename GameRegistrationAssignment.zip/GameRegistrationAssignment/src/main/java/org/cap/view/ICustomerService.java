package org.cap.view;

import org.cap.exception.InvalidMobileException;
import org.cap.exception.InvalidNameException;
import org.cap.model.Customer;

public interface ICustomerService {

	public boolean createCustomer(Customer customer) throws InvalidNameException, InvalidMobileException;

	public String generateExitMsg();

}
