package org.cap.main;

import java.util.Scanner;

import org.cap.exception.InvalidMobileException;
import org.cap.exception.InvalidNameException;
import org.cap.model.Customer;
import org.cap.ui.UserInteraction;
import org.cap.view.CustomerServiceImplementation;
import org.cap.view.ICustomerService;

public class MainClass {

	public static void main(String[] args) throws InvalidNameException, InvalidMobileException {
		
		Scanner scanner=new Scanner(System.in);
		UserInteraction userInteraction=new UserInteraction();
		ICustomerService customerService=new CustomerServiceImplementation();
		String opt = "n";
		boolean flag=false;
		
		do {
			
			System.out.println("Enter your option");
			System.out.println("1.Customer Registration");
			System.out.println("2.Exit");
			
			int choice=scanner.nextInt();
			switch(choice) {
			case 1:
				Customer customer=userInteraction.getCustomerDetails();	
				if(customerService.createCustomer(customer)) System.out.println("successful");;
				break;
			case 2:
				System.out.println(customerService.generateExitMsg());
				flag=true;
				break;
			default:
				System.out.println("Enter 1/2");
				break;
			}
			
			if(!flag){
				System.out.println("Register another customer?[y|n]");
				opt=scanner.next();
			}
			else break;
			
		}while(opt=="y");
		
	}
}
