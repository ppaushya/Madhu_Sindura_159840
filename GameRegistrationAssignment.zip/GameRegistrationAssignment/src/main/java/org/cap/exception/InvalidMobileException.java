package org.cap.exception;

public class InvalidMobileException extends Exception {
	public InvalidMobileException(String str) {
		super(str);
	}
}
