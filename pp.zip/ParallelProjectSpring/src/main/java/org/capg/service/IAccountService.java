package org.capg.service;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.Transaction;

public interface IAccountService {
	
	public boolean addAccount(Account account);

	public Boolean addTransaction(Transaction transaction);

}
