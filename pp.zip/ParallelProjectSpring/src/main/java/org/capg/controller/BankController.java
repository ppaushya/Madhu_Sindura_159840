package org.capg.controller;

import org.capg.model.Account;
import org.capg.model.Customer;
import org.capg.model.LoginBean;
import org.capg.model.Transaction;
import org.capg.service.IAccountService;
import org.capg.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jdk.jfr.DataAmount;

@RestController
@RequestMapping("/project")
@CrossOrigin(origins="*")
public class BankController {
	
	private String userName;
	
	@Autowired
	ILoginService loginService;
	
	@Autowired
	IAccountService accountService;
	
	@GetMapping(value="/login/{userName}/{password}")
	public ResponseEntity<Boolean> isValidLogin(@PathVariable("userName") String userName, @PathVariable("password") String password)
	{
		
		LoginBean login=new LoginBean(userName, password);
		
		Customer flag=loginService.isValidLogin(login);
		
		System.out.println(flag);
		if(flag!=null) {
			this.userName = userName;
			return  new ResponseEntity<Boolean>(true, HttpStatus.OK);
		} 
		else 
			return  new ResponseEntity<Boolean>(false, HttpStatus.OK); 
	}
	
	@PostMapping(value="/createAccount")
	public ResponseEntity<Boolean> addAccount(@RequestBody Account account){
		System.out.println(account);
		Customer customer=loginService.getCustomer(userName);
		account.setCustomer(customer);
		System.out.println(account);
		Boolean flag=accountService.addAccount(account);
		
		if(flag) 
			return  new ResponseEntity<Boolean>(true, HttpStatus.OK);
		else 
			return  new ResponseEntity<Boolean>(false, HttpStatus.OK); 		
	}
	
	@PostMapping(value="/depositWithdraw")
	public ResponseEntity<Boolean> depositWithdraw(@RequestBody Transaction transaction){
		
		Customer customer=loginService.getCustomer(userName);
		transaction.setCustomer(customer);
		Boolean flag=accountService.addTransaction(transaction);
		
		if(flag) 
			return  new ResponseEntity<Boolean>(true, HttpStatus.OK);
		else 
			return  new ResponseEntity<Boolean>(false, HttpStatus.OK); 		
	}
	
	@PostMapping(value="/fundsTransafer")
	public ResponseEntity<Boolean> fundsTransafer(@RequestBody Transaction transaction){
		
		Customer customer=loginService.getCustomer(userName);
		transaction.setCustomer(customer);
		Boolean flag=accountService.addTransaction(transaction);
		
		if(flag) 
			return  new ResponseEntity<Boolean>(true, HttpStatus.OK);
		else 
			return  new ResponseEntity<Boolean>(false, HttpStatus.OK); 		
	}
	

}
