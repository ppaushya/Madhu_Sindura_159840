package org.capg.dao;

import org.capg.model.Customer;
import org.capg.model.LoginBean;

public interface ILoginDao {

	Customer isValidLogin(LoginBean login);

	Customer getCustomer(String userName);

}
