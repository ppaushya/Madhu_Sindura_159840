package org.customerList.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.customerList.model.Customer;
import org.customerList.service.CustomerServiceImplementation;
import org.customerList.service.ICustomerService;

public class deleteCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ICustomerService customerService=new CustomerServiceImplementation();
       
    public deleteCustomer() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getParameter("delete").toCharArray()[6]);
		int customerId = (int) request.getParameter("delete").toCharArray()[6]-48;
		System.out.println(customerId);
		if(customerService.deleteCustomer(customerId)) {
			System.out.println("Delete succesful");
			response.sendRedirect("customerList");
		}
		else System.out.println("Could not delete...");
	}

}
