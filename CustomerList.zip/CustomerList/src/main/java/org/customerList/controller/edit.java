package org.customerList.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.customerList.model.Customer;
import org.customerList.service.CustomerServiceImplementation;
import org.customerList.service.ICustomerService;

public class edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ICustomerService customerService=new CustomerServiceImplementation();
	
    public edit() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		System.out.println(request.getParameter("edit").toCharArray()[4]);
		int customerId = (int) request.getParameter("edit").toCharArray()[4]-48;
		System.out.println(customerId);
		Customer customer=new Customer();
		List<Customer> customerList=customerService.getCustomerList();
		Iterator<Customer> iterator=customerList.iterator();
		while(iterator.hasNext()) {
			customer=iterator.next();
			if(customer.getCustomerId()==customerId) break;
		}
		out.print("<html>\r\n" + 
				"<head>\r\n" + 
				"	<script>\r\n" + 
				"		function check(){\r\n" + 
				"			document.forms[0].action='editCustomer';\r\n" + 
				"			document.forms[0].submit();\r\n" + 
				"		}\r\n" + 
				"	</script>\r\n" + 
				"<title>Customer List</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"	<form method='post'>\r\n" + 
				"		<table>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>First Name:\r\n" + 
				"				<td><input type='text' name='firstName' value='"+customer.getFirstName()+"'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Last Name:\r\n" + 
				"				<td><input type='text' name='lastName' value='"+customer.getLastName()+"'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Mail Id:\r\n" + 
				"				<td><input type='text' name='mail' value='"+customer.getMailId()+"'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td>Mobile No:\r\n" + 
				"				<td><input type='text' name='mobile' value='"+customer.getMobileNo()+"'>\r\n" + 
				"			<tr>\r\n" + 
				"				<td align='center' colspan='2'><input type='submit' onClick='check();'>\r\n" + 
				"		</table>\r\n" + 
				"	</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
