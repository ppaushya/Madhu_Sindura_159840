package org.customerList.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.customerList.model.Customer;
import org.customerList.service.CustomerServiceImplementation;
import org.customerList.service.ICustomerService;

public class editCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ICustomerService customerService=new CustomerServiceImplementation();
	
    public editCustomer() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int customerId=9;
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String mail=request.getParameter("mail");
		String mobile=request.getParameter("mobile");
		
		Customer customer=new Customer();
		customer.setCustomerId(customerId);
		customer.setFirstName(firstName);
		customer.setLastName(lastName);
		customer.setMailId(mail);
		customer.setMobileNo(mobile);
		
		if(customerService.changeCustomerDetails(customer)) { 
			System.out.println("edit succesful");
			response.sendRedirect("customerList");
		}
		else System.out.println("Could not edit...");
	}

}
