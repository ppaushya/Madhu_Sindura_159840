package org.customerList.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.customerList.service.CustomerServiceImplementation;
import org.customerList.service.ICustomerService;

public class delete extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	ICustomerService customerService=new CustomerServiceImplementation();
    
    public delete() {
        super();
    }
    
    static int x;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	System.out.println(x);
    	int customerId = x;
		System.out.println(customerId);
		if(customerService.deleteCustomer(customerId)) {
			System.out.println("Delete succesful");
			response.sendRedirect("customerList");
		}
		else System.out.println("Could not delete...");
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(request.getParameter("delete"));
    	x=(int) request.getParameter("delete").toCharArray()[6]-48;
		PrintWriter out=response.getWriter();
		out.print("<html>\r\n" + 
				"<head>\r\n" + 
				"<title>Customer List</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"	<h4 align='center'>Are you sure?</h4>\r\n" + 
				"	<form method=\"get\" action=\"delete\">\r\n" + 
				"		<div align='center'>\r\n" + 
				"			<input type='submit' value='YES'>\r\n" + 
				"		</div>\r\n" + 
				"	</form>\r\n" + 
				"	<form method=\"post\" action=\"customerList\">\r\n" + 
				"		<div align='center'>\r\n" + 
				"			<input type='submit' value=' NO '>\r\n" + 
				"		</div>\r\n" + 
				"	</form>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
