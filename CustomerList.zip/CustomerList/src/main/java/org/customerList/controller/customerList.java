package org.customerList.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.customerList.model.Customer;
import org.customerList.service.CustomerServiceImplementation;
import org.customerList.service.ICustomerService;

public class customerList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	ICustomerService customerService=new CustomerServiceImplementation();
	
    public customerList() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		PrintWriter out=response.getWriter();
		List<Customer> customerList=customerService.getCustomerList();
		Iterator<Customer> iterator=customerList.iterator();
		out.print("<html>\r\n" + 
				"<head>\r\n" + 
				"<title>Customer List</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" + 
				"<h3 align='center'>Customer List:</h3>\r\n" + 
				"<table border='1' align='center'>\r\n" + 
				"	<tr>\r\n" + 
				"		<th>Id\r\n" + 
				"		<th>First Name\r\n" + 
				"		<th>Last Name\r\n" + 
				"		<th>Mail id\r\n" + 
				"		<th>Mobile no.\r\n" + 
				"		<th colspan='2'>Edit options\r\n" );
		int x=1;
		while(iterator.hasNext()) {
			Customer customer=(Customer) iterator.next();
			/*HttpSession session= request.getSession();
			session.setAttribute(customer.getCustomerId());*/
			out.print( 
				"	<tr>\r\n" + 
				"		<td>\r\n" + customer.getCustomerId() +
				"		<td>\r\n" + customer.getFirstName() + 
				"		<td>\r\n" + customer.getLastName() +
				"		<td>\r\n" + customer.getMailId() + 
				"		<td>\r\n" + customer.getMobileNo() + 
				"		<td><form method='post' action='edit'><input type='submit' name='edit' value='edit"+x+"'></form>\r\n" + 
				"		<td><form method='post' action='delete'><input type='submit' name='delete' value='delete"+x+"'></form>\r\n");
			x++;
		}
		out.println( 
				"</table>\r\n" + 
				"</body>\r\n" + 
				"</html>");
	}

}
