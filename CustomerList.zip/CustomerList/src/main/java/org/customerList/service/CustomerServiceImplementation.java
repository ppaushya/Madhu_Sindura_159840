package org.customerList.service;

import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import org.customerList.dao.CustomerDaoImplementation;
import org.customerList.dao.ICustomerDao;
import org.customerList.model.Customer;

public class CustomerServiceImplementation implements ICustomerService{

	ICustomerDao customerDao=new CustomerDaoImplementation();
	
	@Override
	public List<Customer> getCustomerList() {
		return customerDao.getCustomerList();
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		return customerDao.deleteCustomer(customerId);
	}

	@Override
	public boolean changeCustomerDetails(Customer customer) {
		return customerDao.changeCustomerDetails(customer);
	}

}
