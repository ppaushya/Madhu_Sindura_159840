package org.customerList.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.customerList.model.Customer;

public class CustomerDaoImplementation implements ICustomerDao{

	private Connection getMysqlDbConnection() {
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/madhu", "root", "India123");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	@Override
	public List<Customer> getCustomerList() {
		String sql="select * from customer";
		List<Customer> custList=new LinkedList<>();
		
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			ResultSet customerList=pst.executeQuery();
			while(customerList.next()) {
				Customer customer=new Customer(customerList.getInt(1), customerList.getString(2), customerList.getString(3), customerList.getString(4), customerList.getString(5));
				custList.add(customer);
			}
			return custList;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		String sql="delete from customer where customerId="+customerId;
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			if(pst.execute()) return false;
			else return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean changeCustomerDetails(Customer customer) {
		String sql="update customer set firstName=?,lastName=?,mailId=?,mobileNo=? where customerId=?";
		try(PreparedStatement pst=getMysqlDbConnection().prepareStatement(sql)){
			pst.setString(1, customer.getFirstName());
			pst.setString(2, customer.getLastName());
			pst.setString(3, customer.getMailId());
			pst.setString(4, customer.getMobileNo());
			pst.setInt(5, customer.getCustomerId());
			if(pst.executeUpdate()>0) return true;								
			else return false;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

}
