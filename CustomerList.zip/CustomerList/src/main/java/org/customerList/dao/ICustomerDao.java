package org.customerList.dao;

import java.sql.ResultSet;
import java.util.LinkedList;
import java.util.List;

import org.customerList.model.Customer;

public interface ICustomerDao {

	List<Customer> getCustomerList();

	boolean deleteCustomer(int customerId);

	boolean changeCustomerDetails(Customer customer);

}
