package creditDebit;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;

import org.cap.dao.AccountDaoImpl;
import org.cap.dao.IAccountDao;
import org.cap.exception.InsufficientbalanceException;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {

	double amount=1000;
	double currentBalance=1;

	IAccountService accountService;

	Account account;
	
	Customer customer;
	
	Transaction transaction;
	
	Address address=new Address("23 North avvenue","Chennai");
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		accountService=new AccountServiceImpl(accountDao);
		
	}
	
	@Mock
	IAccountDao accountDao=new AccountDaoImpl();

	@Given("^Account details$")
	public void account_details() throws Throwable {
		account=new Account(1001, new Customer("Mad", "Sind", address), 2000);
	}

	@When("^Valid amount$")
	public void valid_Transaction_Details() throws Throwable {
		assertFalse(amount<0);
	}

	@Then("^Create new Transaction$")
	public void create_new_Transaction() throws Throwable {

		transaction = new Transaction(1, "credit", LocalDate.now(), account, null, amount, "lets see",customer);

		Mockito.when(accountDao.createTransaction(transaction)).thenReturn(true);

		boolean flag=accountService.createTransaction(transaction);

		Mockito.verify(accountDao).createTransaction(transaction);

	}

	@Given("^Valid Customer details$")
	public void valid_Customer_details() throws Throwable {
		customer=new Customer("Tom", "Jerry", address);
	}

	@When("^No Account found for Customer$")
	public void no_Account_found_for_Customer() throws Throwable {
		assertNotNull(account);
	}

	@Rule
	public ExpectedException thrown=ExpectedException.none();
	@Then("^throw error message 'No Account found'$")
	public void throw_error_message_No_Account_found() throws Throwable {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("No Account found");
		accountService.createTransaction(transaction);
	}

	@Given("^Customer details and Account$")
	public void customer_details_and_Account() throws Throwable {
		Address address=new Address("23 North avvenue","Chennai");
		customer=new Customer("Tom", "Jerry", address);
		account=new Account(1001, customer, 1000);
	}

	@When("^Invalid current balance after transaction$")
	public void invalid_current_balance_after_transaction() throws Throwable {
		assertFalse(currentBalance<0);
	}

	@Rule
	public ExpectedException thrown1=ExpectedException.none();
	@Then("^throw error message 'Cannot perform Transaction'$")
	public void throw_error_message_Cannot_perform_Transaction() throws Throwable {
		thrown1.expect(InsufficientbalanceException.class);
		thrown1.expectMessage("Cannot perform Transaction");
		accountService.createTransaction(transaction);
	}

}
