package org.cap.assignment;

//import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;

public class NewAccounts {
	
	String accountType;
	LocalDate oppeningDate; 
	double openingBalance;
	long accountNo;
	double balance;
	
	public NewAccounts(long accountNo, String accountType, LocalDate oppeningDate, double openingBalance, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.oppeningDate = oppeningDate;
		this.openingBalance = openingBalance;
		this.balance = balance;
	}

	public NewAccounts() {
		super();
		this.accountNo = 0;
		this.accountType = null;
		this.oppeningDate = LocalDate.MIN;
		this.openingBalance = 0;
	}

	public String show(ArrayList<NewAccounts> acc) {
		// TODO Auto-generated method stub
		String str="Account Details: " + getAccountNo() + " "+ getAccountType() + " Balance: " + getBalance();
		return str;
	}

	private double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public LocalDate getOppeningDate() {
		return oppeningDate;
	}

	public void setOppeningDate(LocalDate oppeningDate) {
		this.oppeningDate = oppeningDate;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	
}
