package org.cap.assignment;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Matcher;

public class Main {
	
	static public boolean validate(String regExValidation,String str){
		java.util.regex.Pattern p=java.util.regex.Pattern.compile(regExValidation);
		Matcher match=p.matcher(str);
		return match.find();
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		int trno=0;
		long account=1200000;
		String regExValidation=null;
		Customer[] cus=new Customer[5];
		
		Address[] add =new Address[5];
		Accounts[][] acc=new Accounts[3][4];
		AccountTransactions[] accTran=new AccountTransactions[10];
		
		add[0]=new Address("Madhu","MIPL","Chennai","Tamil Nadu");
		add[1]=new Address("Niha","SIPCOT","Chennai","Tamil Nadu");
		add[2]=new Address("Poornam","PCT","Chennai","Tamil Nadu");
		
		for(int i=0;i<3;i++)for(int j=0;j<4;j++) acc[i][j]=new Accounts();
		acc[0][0]=new Accounts(account++,"FD",LocalDate.of(2002, 2, 2),1000,0);
		acc[0][1]=new Accounts(account++,"RD",LocalDate.of(2002, 2, 2),4000,0);
		acc[0][2]=new Accounts(account++,"Savings",LocalDate.of(2002, 2, 2),3000,0);
		acc[1][0]=new Accounts(account++,"FD",LocalDate.of(2012, 2, 2),1000,0);
		acc[2][0]=new Accounts(account++,"FD",LocalDate.of(2014, 2, 2),1000,0);
		
		for(int i=0;i<5;i++)  cus[i]=new Customer();
		cus[0]=new Customer(1002,"Madhu",add[0],acc[0],"+91-9638285863","madhusindura@gmail.com");
		cus[1]=new Customer(1003,"Niha",add[0],acc[0],"+91-9637275763","niharika@gmail.com");
		cus[2]=new Customer(1004,"Poornam",add[0],acc[0],"+91-9631215163","annapoorna@gmail.com");
		
		String choice;
		
		//adding customer!!
		System.out.println("Add customer? Y/N");
		choice=sc.next();	
		abc:
		while(choice.compareTo("Y")==0){
			System.out.println("Enter the Customer Id: ");
			int tempId=sc.nextInt();
			if(!validate("[1-9][0-9]{5-9}",Integer.toString(tempId))) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer Name: ");
			String tempname=sc.nextLine();
			if(!validate("[a-zA-Z\\ \\]+",tempname)) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer Address: ");
			String tempaddname=sc.nextLine();
			String tempaddress=sc.nextLine();
			String tempcity=sc.nextLine();
			String tempstate=sc.nextLine();
			
			System.out.println("Enter the Customer contact: ");
			String tempcontact=sc.nextLine();
			if(!validate("(+91)-[789][0-9]{9}",tempcontact)) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer email address: ");
			String tempmail=sc.nextLine();
			if(!validate("[a-z]+@[a-z]+.(com|in)",tempmail)) {System.out.println("Invalid");  break abc;}
			
			Address tempadd=new Address(tempaddname,tempaddress,tempcity,tempstate);
			int i=0;
			for(i=0;i<5;i++) 
				if(cus[i].customerId==0) break;
			cus[i-1]=new Customer(tempId,tempname,tempadd,acc[i],tempcontact,tempmail);
			
			System.out.println("Done! :)\n");
			System.out.println("Add another customer? Y/N");
			choice=sc.next();	
			if(choice=="N" || i==4) break;
		}
		
		//displaying customers!!
		for(int i=0;i<5;i++) {
			if(cus[i].customerId==0) break;
			System.out.println(i+1 + ". Customer name: " + cus[i].getName());
		}System.out.println("\n");
		
		System.out.println("Choose customer: ");
		int x=sc.nextInt();		
		cus[x-1].show(add[x-1],acc[x-1]);
				
		
		System.out.println("Create Account: Y/N");
		choice=sc.next();	
		if(choice.compareTo("Y")==0){
			
			int y=0;
			for(y=0;;y++) {
				if(acc[x-1][y].getAccountNo()==0) break;
			}
			acc[x-1][y]=new Accounts();
			System.out.println("Enter number \n1 for FD \n2 for Loan Acc\n3 for savings acc.\n4 for RD");
			int temp=sc.nextInt();	
			switch(temp) {
				case 1:acc[x-1][y]=new Accounts(account++,"FD",LocalDate.now(),1000,0);break;
				case 2:acc[x-1][y]=new Accounts(account++,"Loan",LocalDate.now(),2000,0);break;
				case 3:acc[x-1][y]=new Accounts(account++,"Savings",LocalDate.now(),3000,0);break;
				case 4:acc[x-1][y]=new Accounts(account++,"RD",LocalDate.now(),4000,0);break;
				default:System.out.println("Invalid");;
			}
			System.out.println("Done! :)");
			cus[x-1].show(add[x-1],acc[x-1]);
		}
		
		//transactions!!
		System.out.println("Do you want to make a transaction?: Y/N");
		choice=sc.next();	
		while(choice.compareTo("Y")==0) {	
			
			System.out.println("Enter which account");
			for(int i=0;i<4;i++) {
				if(acc[x-1][i].getAccountNo()==0) break;
				System.out.println((i+1)+". "+acc[x-1][i].show(acc[x-1]));
			}
			int z=sc.nextInt();
			
			System.out.println("Enter if debit true/false");
			boolean isDebit=sc.nextBoolean();
			
			System.out.println("Enter amount");
			long amount=sc.nextLong();
			
			accTran[trno]=new AccountTransactions(isDebit,amount,acc[x-1][z]);
			
			System.out.println("Current account balance: "+acc[x-1][z].balance);
			trno++;	
			
			if(trno==10) {System.out.println("Max 10 transactions allowed!"); break;}
			System.out.println("Do you want to make another transaction?: Y/N");
			choice=sc.next();	
		}
		sc.close();
	}

}
