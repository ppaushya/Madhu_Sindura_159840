package org.cap.assignment;

import java.time.LocalDate;

public class NewAccountTransactions {
	
	double transactionId=1;
	LocalDate transactionDate;
	boolean isDebit;
	long amount;
	NewAccounts acc=new NewAccounts();
	
	public NewAccountTransactions() {
		
	}
	
	public NewAccountTransactions(boolean isDebit,	long amount,NewAccounts acc) {
		super();
		this.acc=acc;
		this.transactionId = transactionId++;
		this.transactionDate = LocalDate.now();
		if(isDebit) debit(amount);
		else credit(amount);
	}
	
	public double debit(long amount2) {
		acc.balance-=amount2;
		return acc.balance-amount2;
	}
	
	public double credit(long amount2) {
		acc.balance+=amount2;
		return acc.balance+amount2;
	}

	@Override
	public String toString() {
		return "AccountTransaction:\n [accountNo=" + acc.accountNo + ", transactionId=" + transactionId + ", transactionDate="
				+ transactionDate + ", isDebit=" + isDebit + ", amount=" + amount + ", acc=" + acc + "]";
	}
	
	

	public double getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(double transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public boolean isDebit() {
		return isDebit;
	}
	public void setDebit(boolean isDebit) {
		this.isDebit = isDebit;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
	
}
