package org.cap.assignment;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;


public class NewMain {

	public boolean validate(String regExValidation,String str){
		java.util.regex.Pattern p=java.util.regex.Pattern.compile(regExValidation);
		Matcher match=p.matcher(str);
		return match.find();
	}
	
	public static void main(String[] args) {
		NewMain mainObj=new NewMain();
		
		Scanner sc=new Scanner(System.in);
		long account=1200000;
		String choice;
		
		List<NewCustomer> customerList=new ArrayList<>();
		List<Address> address =new ArrayList<>();
		List<List<NewAccounts>> accounts=new ArrayList<>();
		List<NewAccountTransactions> accTran=new ArrayList<>();
		
		//temporary classes for declaring
		Address tempAddress;
		ArrayList<NewAccounts> tempAccount=new ArrayList<>();
		
		//Cutomer1
		tempAddress=new Address("Madhu","MIPL","Chennai","Tamil Nadu");
		address.add(tempAddress);
		tempAccount.add(0,new NewAccounts(account++,"FD",LocalDate.of(2002, 2, 2),1000,0));
		tempAccount.add(new NewAccounts(account++,"RD",LocalDate.of(2012, 5, 2),4000,0));
		tempAccount.add(new NewAccounts(account++,"Savings",LocalDate.of(2015, 7, 2),3000,0));
		customerList.add(new NewCustomer(1002,"Madhu",tempAddress,tempAccount,"+91-9638285863","madhusindura@gmail.com"));
		
		//Customer2
		tempAddress=new Address("Niha","SIPCOT","Chennai","Tamil Nadu");
		address.add(tempAddress);
		tempAccount.clear();
		tempAccount.add(0,new NewAccounts(account++,"FD",LocalDate.of(2012, 2, 2),1000,0));
		customerList.add(new NewCustomer(1003,"Niha",tempAddress,tempAccount,"+91-9637275763","niharika@gmail.com"));
		
		//Customer3
		tempAddress=new Address("Poornam","PCT","Chennai","Tamil Nadu");
		address.add(tempAddress);
		tempAccount.clear();
		tempAccount.add(0,new NewAccounts(account++,"FD",LocalDate.of(2014, 2, 2),1000,0));
		customerList.add(new NewCustomer(1004,"Poornam",tempAddress,tempAccount,"+91-9631215163","annapoorna@gmail.com"));
		
		//adding customer!!
		System.out.println("Add customer? Y/N");
		choice=sc.next();	
		abc:
		while(choice.compareTo("Y")==0){
			System.out.println("Enter the Customer Id: ");
			int tempId=sc.nextInt();
			if(!mainObj.validate("[1-9][0-9]{5-9}",Integer.toString(tempId))) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer Name: ");
			String tempname=sc.nextLine();
			if(!mainObj.validate("[a-zA-Z\\ \\]+",tempname)) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer Address: ");
			String tempaddname=sc.nextLine();
			String tempaddress=sc.nextLine();
			String tempcity=sc.nextLine();
			String tempstate=sc.nextLine();
			
			System.out.println("Enter the Customer contact: ");
			String tempcontact=sc.nextLine();
			if(!mainObj.validate("(+91)-[789][0-9]{9}",tempcontact)) {System.out.println("Invalid");  break abc;}
			
			System.out.println("Enter the Customer email address: ");
			String tempmail=sc.nextLine();
			if(!mainObj.validate("[a-z]+@[a-z]+.(com|in)",tempmail)) {System.out.println("Invalid");  break abc;}
			
			tempAddress=new Address(tempaddname,tempaddress,tempcity,tempstate);
			customerList.add(new NewCustomer(tempId,tempname,tempAddress,new ArrayList<NewAccounts>(),tempcontact,tempmail));
			
			System.out.println("Done! :)\n");
			System.out.println("Add another customer? Y/N");
			choice=sc.next();	
			if(choice=="N") break;
		}
		
		//displaying customers!!
		for(NewCustomer cus: customerList) 
			System.out.print("Customer Id: "+cus.customerId+" Name: "+cus.name+"\n");	
		System.out.println("\n");
		
		System.out.println("Choose customer: ");
		int x=sc.nextInt();
		
		/*NewCustomer tempCus;
		tempCus=customerList.get(x-1);*/
		
		//displays all the selected customer
		customerList.get(x-1).show(customerList.get(x-1).address, customerList.get(x-1).accounts);
		
		//creating new account 
		System.out.println("Create Account: Y/N");
		choice=sc.next();	
		if(choice.compareTo("Y")==0){
			System.out.println("Enter number \n1 for FD \n2 for Loan Acc\n3 for savings acc.\n4 for RD");
			int temp=sc.nextInt();	
			switch(temp) {
				case 1:accounts.get(x-1).add(new NewAccounts(account++,"FD",LocalDate.now(),1000,0));break;
				case 2:accounts.get(x-1).add(new NewAccounts(account++,"Loan",LocalDate.now(),2000,0));break;
				case 3:accounts.get(x-1).add(new NewAccounts(account++,"Savings",LocalDate.now(),3000,0));break;
				case 4:accounts.get(x-1).add(new NewAccounts(account++,"RD",LocalDate.now(),4000,0));break;
				default:System.out.println("Invalid");;
			}
			System.out.println("Done! :)");
			customerList.get(x-1).show(customerList.get(x-1).address, customerList.get(x-1).accounts);
		}
		
		//transactions!!
		System.out.println("Do you want to make a transaction?: Y/N");
		choice=sc.next();
		
		while(choice.compareTo("Y")==0) {	
			
			System.out.println("Enter which account");		
			int z=sc.nextInt();
			customerList.get(z-1);
			
			System.out.println("Enter if debit true/false");
			boolean isDebit=sc.nextBoolean();
					
			System.out.println("Enter amount");
			long amount=sc.nextLong();
					
			accTran.add(new NewAccountTransactions(isDebit,amount,customerList.get(x-1).accounts.get(z-1)));
			
			System.out.println("Current account balance: "+customerList.get(x-1).accounts.get(z-1).balance);
					
			System.out.println("Do you want to make another transaction?: Y/N");
			choice=sc.next();	
		}
		sc.close();
		
	}

}
