package org.cap.assignment;

public class Address {
	
	String name;
	String address;
	String city;
	String state;
	
	public Address() {
		super();
		this.name = null;
		this.address = null;
		this.city = null;
		this.state = null;
	}
	
	public Address(String name, String address, String city, String state) {
		super();
		this.name = name;
		this.address = address;
		this.city = city;
		this.state = state;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	public String show(Address add) {
		// TODO Auto-generated method stub
		String str="c/o " + getName() + " " + getAddress() + " " + getCity() + " " + getState();
		return str;
	}
	
}
