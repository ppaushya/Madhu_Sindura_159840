package org.cap.assignment;

import java.util.ArrayList;

public class NewCustomer {
	
	int customerId;
	String name;
	Address address;//=new Address();
	ArrayList<NewAccounts> accounts;//=new Accounts[5];
	String mobileno;
	String mail;
	
	public NewCustomer() {
		super();
		this.customerId = 0;
		this.name = null;
		this.address = null;
		this.accounts = null;
		this.mobileno = null;
		this.mail = null;
	}
	public NewCustomer(int customerId, String name, Address address, ArrayList<NewAccounts> accounts, String mobileno, String mail) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.accounts = accounts;
		this.mobileno = mobileno;
		this.mail = mail;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}

	public ArrayList<NewAccounts> getAccounts() {
		return accounts;
	}

	public String getMobileno() {
		return mobileno;
	}

	public String getMail() {
		return mail;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setAccounts(ArrayList<NewAccounts> accounts) {
		this.accounts = accounts;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public void show(Address address,ArrayList<NewAccounts> accounts) {
		// TODO Auto-generated method stub
		System.out.println("Customer name: "+ name + "\nCustomer Id: "+ customerId + "\nAddress: " + address.show(address) + "\nEmail address: " + mail + "\nContact: " + mobileno + "\nAccounts: ");
		for(NewAccounts acc: accounts) 
			System.out.print("Account no: "+acc.accountNo+" Acoount type: "+acc.accountType+" Balance: "+acc.balance);	
		System.out.println("");
	}
	
}
