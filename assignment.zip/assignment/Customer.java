package org.cap.assignment;

public class Customer {
	
	int customerId;
	String name;
	Address address;//=new Address();
	Accounts[] accounts;//=new Accounts[5];
	String mobileno;
	String mail;
	
	public Customer() {
		super();
		this.customerId = 0;
		this.name = null;
		this.address = null;
		this.accounts = null;
		this.mobileno = null;
		this.mail = null;
	}
	public Customer(int customerId, String name, Address address, Accounts[] accounts, String mobileno, String mail) {
		super();
		this.customerId = customerId;
		this.name = name;
		this.address = address;
		this.accounts = accounts;
		this.mobileno = mobileno;
		this.mail = mail;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public String getName() {
		return name;
	}

	public Address getAddress() {
		return address;
	}

	public Accounts[] getAccounts() {
		return accounts;
	}

	public String getMobileno() {
		return mobileno;
	}

	public String getMail() {
		return mail;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void setAccounts(Accounts[] accounts) {
		this.accounts = accounts;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public void show(Address add,Accounts[] acc) {
		// TODO Auto-generated method stub
		System.out.println("Customer name: "+ name + "\nCustomer Id: "+ customerId + "\nAddress: " + add.show(add) + "\nEmail address: " + mail + "\nContact: " + mobileno + "\nAccounts: ");
		for(int i=0;i<4;i++) {
			if(acc[i].getAccountNo()==0) break;
			System.out.print((i+1)+". "+acc[i].show(acc)+"  ");
		}
		System.out.println("");
	}
	
}
