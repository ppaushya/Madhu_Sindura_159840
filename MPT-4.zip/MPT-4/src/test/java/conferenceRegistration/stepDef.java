package conferenceRegistration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDef {

	private WebDriver webdriver;
	
	private String title,heading;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\mbommath\\Downloads\\chromedriver.exe");
		webdriver= new ChromeDriver();
	}

	@Given("^conference page$")
	public void conference_page() throws Throwable {
		webdriver.get("file:///C:/Users/mbommath/Downloads/Conferencebooking/ConferenceRegistartion.html#");
	}

	@When("^title is not 'Conference Registration'$")
	public void title_is_not_Conference_Registration() throws Throwable {
		title = webdriver.getTitle();
		assertNotEquals("Conference Registration", title);
	}

	@Then("^quit test$")
	public void quit_test() throws Throwable {
		webdriver.quit();
	}

	@When("^heading is not 'Personal Details'$")
	public void heading_is_not_Personal_Details() throws Throwable {
		heading = webdriver.findElement(By.tagName("h2")).getText();
		assertNotEquals("Personal Details", heading);
	}

	@When("^first name is null and next is clicked$")
	public void first_name_is_null_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Please fill the First Name'$")
	public void alert_box_displays_Please_fill_the_First_Name() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alertFN);
		if(alertFN.equals("Please fill the First Name"))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^last name is null and next is clicked$")
	public void last_name_is_null_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Please fill the Last Name'$")
	public void alert_box_displays_Please_fill_the_Last_Name() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Last Name", alertFN);
		if(alertFN.equals("Please fill the Last Name"))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^email is null and next is clicked$")
	public void email_is_null_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("Cat");
		webdriver.findElement(By.name("Email")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Please fill the Email'$")
	public void alert_box_displays_Please_fill_the_Email() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Email", alertFN);
		if(alertFN.equals("Please fill the Email"))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^contact no\\. is null and next is clicked$")
	public void contact_no_is_null_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("Cat");
		webdriver.findElement(By.name("Email")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("");
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Please fill the Contact No\\.'$")
	public void alert_box_displays_Please_fill_the_Contact_No() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Contact No.", alertFN);
		if(alertFN.equals("Please fill the Contact No."))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^contact no\\. does not match pattern and next is clicked$")
	public void contact_no_does_not_match_pattern_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("Cat");
		webdriver.findElement(By.name("Email")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("123456789");
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Please enter valid Contact no\\.'$")
	public void alert_box_displays_Please_enter_valid_Contact_no() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please enter valid Contact no.", alertFN);
		if(alertFN.equals("Please enter valid Contact no."))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^Number of people attending is not selected and next is clicked$")
	public void number_of_people_attending_is_not_selected_and_next_is_clicked() throws Throwable {		
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("Cat");
		webdriver.findElement(By.name("Email")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9876543210");
		Select select = new Select(webdriver.findElement(By.name("size")));
		//select.deselectAll();
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Number of people attending'$")
	public void alert_box_displays_Number_of_people_attending() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Please fill the Number of people attending", alertFN);
		if(alertFN.equals("Please fill the Number of people attending"))
			System.out.println("true");
		else System.out.println("false");
	}

	@When("^valid details given and next is clicked$")
	public void valid_details_given_and_next_is_clicked() throws Throwable {
		webdriver.findElement(By.name("txtFN")).sendKeys("Tom");
		webdriver.findElement(By.name("txtLN")).sendKeys("Cat");
		webdriver.findElement(By.name("Email")).sendKeys("tom@gmail.com");
		webdriver.findElement(By.name("Phone")).sendKeys("9876543210");
		Select select = new Select(webdriver.findElement(By.name("size")));
		select.selectByIndex(1);
		webdriver.findElement(By.name("Address")).sendKeys("MIPL");
		webdriver.findElement(By.name("Address2")).sendKeys("Mahindra World City");
		Select selectCity = new Select(webdriver.findElement(By.name("city")));
		selectCity.selectByIndex(1);
		Select selectState = new Select(webdriver.findElement(By.name("state")));
		selectState.selectByIndex(1);
		webdriver.findElement(By.name("memberStatus")).click();
		webdriver.findElement(By.tagName("a")).click();
	}

	@Then("^alert box displays 'Personal details are validated'$")
	public void alert_box_displays_Personal_details_are_validated() throws Throwable {
		String alertFN=webdriver.switchTo().alert().getText();
		assertEquals("Personal details are validated.", alertFN);
		webdriver.switchTo().alert().accept();
		webdriver.navigate().to("file:///C:/Users/mbommath/Downloads/Conferencebooking/PaymentDetails.html");
	}

}
