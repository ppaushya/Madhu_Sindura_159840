package org.cap.controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.model.Customer;
import org.cap.model.Register;
import org.cap.service.IRegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class RegisterController {

	private Register register;
	@Autowired
	private IRegisterService registerService;
	private boolean flag;
	private String butLabel;

	@RequestMapping("/register")
	public String showRegistrationPage(ModelMap map) {
		List<Register> registers= registerService.getAllRegistration();
		butLabel="Update";

		if(!flag) {
			butLabel="Register";
			map.addAttribute("register", new Register());
		}
		else
			map.addAttribute("register",register);

		map.addAttribute("butLabel",butLabel);
		map.addAttribute("registers", registers);
		map.addAttribute("flag", flag);
		flag=false;
		return "register";
	}


	@PostMapping("/registerForm")
	public String registerDetails(
			@Valid @ModelAttribute("register")Register register,
			BindingResult result,
			HttpSession session) {
		if(butLabel.equals("Register")) {
			if(result.hasErrors())
				return "register";
			else{
				int customerId=Integer.parseInt(session.getAttribute("custId").toString());
				Customer customer=new Customer();
				customer.setCustomerId(customerId);
				register.setCustomer(customer);
				registerService.insertRegistration(register);
				System.out.println(register);
				return "redirect:register";
			}
		}
		else if(butLabel.equals("Update")) {
			if(registerService.updateRegistration(register))
				return "redirect:register";
		}
		return "redirect:register";
	}



	@RequestMapping("/delete/{registrationId}")
	public String deleteRegistration(@PathVariable("registrationId") Integer registrationId) {

		registerService.deleteRegistration(registrationId);

		return "redirect:/register";
	}


	@RequestMapping("/edit/{registrationId}")
	public String editRegistration(@PathVariable("registrationId") Integer registrationId) {

		flag=true;
		register=registerService.findRegistration(registrationId);
		return "redirect:/register";
	}













}
















