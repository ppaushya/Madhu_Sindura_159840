package org.cap.dao;


import org.cap.model.Customer;
import org.cap.model.LoginPojo;

public interface ILoginDao {

	
	public Customer isValidLogin(LoginPojo loginPojo);
	
	
}
