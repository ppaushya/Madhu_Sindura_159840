package org.mno.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.mno.model.Account;
import org.mno.model.Address;
import org.mno.model.Customer;
import org.mno.model.Transaction;

public class CustomerDaoImplementation implements ICustomerDao{
private static List<Customer> customers=dummy();

	private Connection getDbConnection() {
		Connection connection=null;;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root" , "India123");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}

	private static List<Customer> dummy(){
		
		List<Customer> customers=new ArrayList<>();
		Address address;
			
		address=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jack","Thomson", "jack@gmail.com","8890912345",LocalDate.of(1991, 01, 23),
				address,new HashSet<Account>()));
		
		address=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry","tom@gmail.com","9090912345", LocalDate.of(1987, 12, 23),
				address,new HashSet<Account>()));
		
		return customers;
	}
	
	
	@Override
	public ResultSet getCustomersList() {
		String sql="select * from customer;";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			ResultSet customers=statement.executeQuery();			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return (ResultSet) customers;
		
	}

	@Override
	public void createCustomer(Customer customer) {
		String sql="insert into customer values(?,?,?,?,?);";
		String sqlAddress="insert into address values(?,?,?,?,?,?);";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			statement.setString(2, customer.getFirstName());
			statement.setString(3, customer.getLastName());
			statement.setString(4,customer.getEmailId());
			statement.setString(5,customer.getMobileNo());
			statement.setDate(6,Date.valueOf(customer.getDateOfBirth()));
			int count=statement.executeUpdate();			
			statement=conn.prepareStatement(sqlAddress);
			statement.setString(1, customer.getAddress().getAddressLine1());
			statement.setString(2, customer.getAddress().getAddressLine2());
			statement.setString(3, customer.getAddress().getCity());
			statement.setString(4, customer.getAddress().getState());
			statement.setString(5, customer.getAddress().getPinCode());
			count+=statement.executeUpdate();			
			if(count>0) {
				System.out.println("RegistrationId: "+customer.getCustomerId()+" Insertion complete!");
			}else System.out.println("Could not insert!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		customers.add(customer);
		System.out.println("customer123");	
	}


	@Override
	public void createAccount(Account account, Customer customer) {
		String sql="insert into account values(?,?,?,?,?,?);";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			statement.setLong(2, account.getAccountNumber());
			statement.setString(3, account.getAccountType());
			statement.setDate(4,Date.valueOf(account.getOpeningdate()));
			statement.setDouble(5, account.getOpeningBalance());
			statement.setString(6, account.getDescription());
			int count=statement.executeUpdate();			
			if(count>0) {
				System.out.println("Account number: "+account.getAccountNumber()+" Insertion complete!");
			}else System.out.println("Could not insert!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		customer.getAccount().add(account);
		System.out.println("account123");
	}


	@Override
	public void createTransaction(Transaction transaction,Account account) {
		String sql="insert into transaction values(?,?,?,?,?,?,?,?);";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setLong(1, account.getAccountNumber());
			statement.setLong(2, transaction.getTransactionId());
			statement.setDate(3, Date.valueOf(transaction.getTransactionDate()));
			statement.setLong(4, transaction.getFromAccount().getAccountNumber());
			statement.setLong(5, transaction.getToAccount().getAccountNumber());
			statement.setString(6, transaction.getTransactionType());
			statement.setDouble(7, transaction.getAmount());
			statement.setString(8, transaction.getDescription());
			int count=statement.executeUpdate();			
			if(count>0) {
				System.out.println("Account number: "+account.getAccountNumber()+" Insertion complete!");
			}else System.out.println("Could not insert!");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		account.getTransaction().add(transaction);
		System.out.println("transaction123");
	}

	@Override
	public ResultSet getCustomersList(long tempCustomerId) {
		String sql="select * from customer where customerId="+tempCustomerId+";";
		try(Connection conn=getDbConnection()) {
			PreparedStatement statement=conn.prepareStatement(sql);
			ResultSet customers=statement.executeQuery();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return (ResultSet) customers;
	}
	
}