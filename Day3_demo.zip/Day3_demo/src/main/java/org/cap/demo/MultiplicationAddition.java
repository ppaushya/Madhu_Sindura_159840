package org.cap.demo;

import java.util.Scanner;

public class MultiplicationAddition {

	int myArray[][],myArray2[][];
	Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MultiplicationAddition obj=new MultiplicationAddition();
		int rows=obj.sc.nextInt();
		int cols=obj.sc.nextInt();;
		obj.myArray=new int[rows][cols];
		
		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				System.out.println("Enter for: "+ i+" "+j);
				obj.myArray[i][j]=obj.sc.nextInt();
			}
		}
		
		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				System.out.print(obj.myArray[i][j]+" ");
			}
			System.out.println();
		}
		
		
		int rows1=obj.sc.nextInt();
		int cols1=obj.sc.nextInt();;
		obj.myArray2=new int[rows][cols];
		
		for(int i=0;i<rows1;i++) {
			for(int j=0;j<cols1;j++) {
				System.out.println("Enter for: "+ i+" "+j);
				obj.myArray2[i][j]=obj.sc.nextInt();
			}
		}
		
		for(int i=0;i<rows1;i++) {
			for(int j=0;j<cols1;j++) {
				System.out.print(obj.myArray2[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("Addition");
		obj.addition(rows,cols,rows1,cols1);
		System.out.println("\n\n");
		System.out.println("Multiplication");
		obj.multiplication(rows,cols,rows1,cols1);
		
	}

	private void addition(int x,int y,int x1,int y1) {
		// TODO Auto-generated method stub
		if(x==x1 && y==y1) {
			for(int i=0;i<x;i++) {
				for(int j=0;j<y;j++) {
					System.out.print(myArray[i][j]+myArray2[i][j]+" ");
				}
				System.out.println();
			}			
		}
		else System.out.println("Not Possible");
	}

	private void multiplication(int x,int y,int x1,int y1) {
		// TODO Auto-generated method stub
		int temp=0;
		if(y==x1) {
			for(int i=0;i<x;i++) {
				for(int j=0;j<y1;j++) {
					for(int k=0;k<y;k++) {
						temp+=myArray[i][k]*myArray2[k][i];
					}
					System.out.print(temp+" ");
					temp=0;
				}
				System.out.println();
			}			
		}else System.out.println("Not Possible");
	}

}
