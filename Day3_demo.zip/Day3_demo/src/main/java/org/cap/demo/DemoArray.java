package org.cap.demo;

import java.util.Scanner;

public class DemoArray {

	int myArr[];
	Scanner sc=new Scanner(System.in);
	
	public void getArrayElements(int size) {
		sc.nextLine();//sc.nextLine();
		for(int i=0;i<size;i++) {
			System.out.print("Element "+(i+1)+"\n");
			myArr[i]=sc.nextInt();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DemoArray obj=new DemoArray();
		
		System.out.println(obj.myArr);
		
		System.out.println("\nHow many Elements: ");
		int x=obj.sc.nextInt();
		obj.myArr=new int[x];
		obj.getArrayElements(x);
		
		System.out.println("\nArray: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
	}

}
