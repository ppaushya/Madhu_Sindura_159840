package org.cap.demo;

import java.util.Scanner;

public class BubbleSort {

	int myArr[],revArr[];
	Scanner sc=new Scanner(System.in);
	
	public void getArrayElements(int size) {
		sc.nextLine();
		for(int i=0;i<size;i++) {
			System.out.print("Element "+(i+1)+"\n");
			myArr[i]=sc.nextInt();
		}
	}
	
	public void bubbleSort(int size) {
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(myArr[i]>myArr[j]) swap(i,j);
			}
		}
	}
	
	public void swap(int a,int b) {
		int temp;
		temp=myArr[a];myArr[a]=myArr[b];myArr[b]=temp;
		return;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BubbleSort obj=new BubbleSort();
		
		System.out.println("How many Elements: ");
		int x=obj.sc.nextInt();
		
		obj.myArr=new int[x];
		obj.revArr=new int[x];

		obj.getArrayElements(x);
		System.out.println("\nArray: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
		
		obj.bubbleSort(x);
		System.out.println("\nSorted array: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
	}

}
