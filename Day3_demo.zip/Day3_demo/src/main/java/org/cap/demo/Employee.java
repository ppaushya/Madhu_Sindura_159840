package org.cap.demo;

import java.util.Scanner;

public class Employee {

	Scanner sc=new Scanner(System.in);
	String firstName,lastName;
	int age,id,salary;
	Employee emp[]; 
	
	public void getEmployeeDetails(int x) {
		for(int i=0;i<x;i++) {
			System.out.println("Enter id: ");
			emp[i].id=sc.nextInt();
			sc.nextLine();
			System.out.println("Enter firstNAme: ");
			emp[i].firstName=sc.nextLine();
			System.out.println("Enter lastName: ");
			emp[i].lastName=sc.nextLine();
			System.out.println("Enter Age: ");
			emp[i].age=sc.nextInt();
			System.out.println("Enter salary: ");
			emp[i].salary=sc.nextInt();
		}
	}
	
	public void empSort(int size) {
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(emp[i].id>emp[j].id) swap(i,j);
			}
		}
	}
	
	public void swap(int a,int b) {
		Employee temp;
		temp=emp[a];emp[a]=emp[b];emp[b]=temp;
		return;
	}
	
	public void printEmployeeDetails(int x) {
		for(int i=0;i<x;i++) {
			System.out.print(emp[i].id+" ");
			System.out.print(emp[i].firstName);
			System.out.print(" "+emp[i].lastName);
			System.out.print(" "+emp[i].age);
			System.out.println(" "+emp[i].salary);
		}
	}
	
	public void bubbleSort(Employee[] emp2) {
		for(int i=0;i<emp2.length;i++) {
			for(int j=i+1;j<emp2.length;j++) {
				if(emp2[i].id>emp2[j].id) swap(i,j);
			}
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee obj=new Employee();
		int s=obj.sc.nextInt();
		obj.emp=new Employee[s];
		for(int i=0;i<s;i++) obj.emp[i]=new Employee();
		
		obj.getEmployeeDetails(s);
		obj.printEmployeeDetails(s);
		//obj.empSort(s);
		obj.bubbleSort(obj.emp);
		obj.printEmployeeDetails(s);	
	}

}
