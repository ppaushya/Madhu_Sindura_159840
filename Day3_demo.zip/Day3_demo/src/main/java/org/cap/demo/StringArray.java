package org.cap.demo;

import java.util.Scanner;

public class StringArray {

	String[] myStr;
	
	public void accptString(int size) {
		
		Scanner sc=new Scanner(System.in);
		myStr=new String[size];
		
		System.out.println("Enter "+size+" String elements: ");
		for(int i=0;i<size;i++) myStr[i]=sc.nextLine();
		
		sc.close();
	}
	
	
	public void stringSort(int size) {
		for(int i=0;i<size;i++) {
			for(int j=i+1;j<size;j++) {
				if(myStr[i].compareTo(myStr[j])>0) swap(i,j);
			}
		}
	}
	
	public void swap(int a,int b) {
		String temp;
		temp=myStr[a];myStr[a]=myStr[b];myStr[b]=temp;
		return;
	}
	
	public void revStringElements(int size) {
		String temp="";
		for(int i=0;(i%2==0)?(i<size/2):(i<(size-1)/2);i++) {
			temp=myStr[i];
			myStr[i]=myStr[size-i-1];
			myStr[size-i-1]=temp;
		}
	}
	
	public void printString() {
		for(int i=0;i<myStr.length;i++) System.out.println(myStr[i]);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringArray obj=new StringArray();
		obj.accptString(5);
		System.out.println("\nInput: ");
		obj.printString();
		obj.revStringElements(5);
		System.out.println("\nReverse: ");
		obj.printString();
		obj.stringSort(5);
		System.out.println("\nSorted: ");
		obj.printString();
	}

}
