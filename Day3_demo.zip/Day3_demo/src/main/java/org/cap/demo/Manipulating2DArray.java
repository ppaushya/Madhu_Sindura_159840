package org.cap.demo;

import java.util.Scanner;

public class Manipulating2DArray {

	int myArray[][];
	Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manipulating2DArray obj=new Manipulating2DArray();
		int rows=obj.sc.nextInt();
		obj.myArray=new int[rows][];
		
		for(int i=0;i<rows;i++) {
			int cols=obj.sc.nextInt();;
			obj.myArray[i]=new int[cols];
			for(int j=0;j<cols;j++) {
				System.out.println("Enter for: "+ i+" "+j);
				obj.myArray[i][j]=obj.sc.nextInt();
			}
		}
		
		for(int i=0;i<rows;i++) {
			for(int j=0;j<obj.myArray[i].length;j++) {
				System.out.print(obj.myArray[i][j]+" ");
			}
			System.out.println();
		}
		obj.getArraySum(rows);
		System.out.println("\n\n");
		obj.getArraySeq(rows);
	}

	public void getArraySum(int x) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=0;i<x;i++) {
			for(int j=0;j<myArray[i].length;j++) {
				sum+=myArray[i][j];
			}
			System.out.println("Sum of "+(i+1)+" column elements: "+sum);
			sum=0;
		}
	}
	
	private int inSequence(int[] x) {
		for(int i=0;i<x.length;i++) 
			if(x[i+1]-x[i]!=1) return i;
		return x.length;
	}
	
	public void getArraySeq(int x) {
		// TODO Auto-generated method stub
		for(int i=0;i<x;i++) {
			for(int j=0;j<myArray[i].length;j++) {
				myArray[i]=sort(myArray[i]);
				int a=inSequence(myArray[i]);
				if(a==myArray[i].length) System.out.println("Value: "+myArray[i][a-1]+1);
				else System.out.println("Value: "+myArray[i][a]+1);
			}
		}
	}
	
	public int[] sort(int[] x) {
		for(int i=0;i<x.length;i++) {
			for(int j=i+1;j<x.length;j++) {
				if(x[i]>x[j]) {int temp=x[i];x[i]=x[j];x[j]=temp;}
			}
		}
		return x;
	}
	
}
