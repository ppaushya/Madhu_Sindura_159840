package org.cap.demo;

import java.util.Scanner;

public class ArrayFunctions {

	int myArr[],revArr[];
	Scanner sc=new Scanner(System.in);
	
	public void getArrayElements(int size) {
		sc.nextLine();
		for(int i=0;i<size;i++) {
			System.out.print("Element "+(i+1)+"\n");
			myArr[i]=sc.nextInt();
		}
	}
	
	public int smallestElement(int x) {
		// TODO Auto-generated method stub
		int smallest=myArr[0];
		for(int i=0;i<x;i++) {
			if(myArr[i]<smallest) smallest=myArr[i];
		}
		return smallest;
	}

	public int biggestElement(int x) {
		// TODO Auto-generated method stub
		int biggest=myArr[0];
		for(int i=0;i<x;i++) {
			if(myArr[i]>biggest) biggest=myArr[i];
		}
		return biggest;
	}

	public int secondBiggestElement(int x) {
		// TODO Auto-generated method stub
		int biggest=myArr[0],y=biggestElement(x);
		for(int i=0;i<x;i++) {
			if(myArr[i]>biggest && myArr[i]<y) biggest=myArr[i];
		}
		return biggest;
	}

	public void evenNumbersPrint(int x) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=0;i<x;i++) {
			if(myArr[i]%2==0) {
				System.out.print(myArr[i]+" ");
				sum+=myArr[i];
			}
		}
		System.out.print("\n\nSum of all the even numbers in the array: "+sum);
		return;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayFunctions obj=new ArrayFunctions();
		
		System.out.println("How many Elements: ");
		int x=obj.sc.nextInt();
		
		obj.myArr=new int[x];
		obj.revArr=new int[x];

		obj.getArrayElements(x);
		System.out.println("\nArray: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
		
		System.out.println("\n\nBiggest Element: ");
		System.out.print(obj.biggestElement(x));

		System.out.println("\n\nSmallest Element: ");
		System.out.print(obj.smallestElement(x));
		
		System.out.println("\n\nEven numbers in the array: ");
		obj.evenNumbersPrint(x);

		System.out.println("\n\nSecond biggest Element: ");
		System.out.print(obj.secondBiggestElement(x));
	}

}
