package org.cap.demo;

public class TestArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num[]=new int[10];
		short myNum=9;
		
		num[0]=0;num[2]=2;num[6]=6;num[8]=8;num[9]=myNum;//num[5]=(int) myNum2;
		num[3]=(int)Math.PI;
		
		for(int i=0;i<10;i++)System.out.print(num[i]+" ");
		
		System.out.println("Size of num: \n"+num.length+"\n");
		
		
		int num2[]={1,2,3,4,5};
		
		for(int i=0;i<num2.length;i++)System.out.print(num2[i]+" ");
	}

}
