package org.cap.demo;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int num[]={1,2,3,4,5,6,7,8,9,0};//new int[10];
		 int a=-1;
		 System.out.print(num[a]); 

	}

}
