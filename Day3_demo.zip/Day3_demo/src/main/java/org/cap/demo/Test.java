package org.cap.demo;

public class Test {

	public static void printData(int...x) {
		for(int value: x) {
			System.out.print(value+" ");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x= {1,2,3,4,5,6,7,8,9,10,11,12};
		printData(x);
	}

}
