package org.cap.demo;

import java.util.Scanner;

public class ReverseArray {

	int myArr[],revArr[];
	Scanner sc=new Scanner(System.in);
	
	public void getArrayElements(int size) {
		sc.nextLine();//sc.nextLine();
		for(int i=0;i<size;i++) {
			System.out.print("Element "+(i+1)+"\n");
			myArr[i]=sc.nextInt();
		}
	}
	
	public void revArrayElements(int size) {
		for(int i=0,j=size-1;j>=0;j--,i++) {
			revArr[i]=myArr[j];
		}
	}
	
	public void revSameArrayElements(int size) {
		int temp=0;
		for(int i=0;(i%2==0)?(i<size/2):(i<(size-1)/2);i++) {
			temp=myArr[i];
			myArr[i]=myArr[size-i-1];
			myArr[size-i-1]=temp;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ReverseArray obj=new ReverseArray();
		
		System.out.println(obj.myArr);
		
		System.out.println("\nHow many Elements: ");
		int x=obj.sc.nextInt();
		obj.myArr=new int[x];obj.revArr=new int[x];
		obj.getArrayElements(x);
		System.out.println("\nArray: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
		
		obj.revArrayElements(x);
		System.out.println("\nNew array: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.revArr[i]+" ");
		
		obj.revSameArrayElements(x);
		System.out.println("\nReverse in same array: ");
		for(int i=0;i<obj.myArr.length;i++) System.out.print(obj.myArr[i]+" ");
		
	}

}
