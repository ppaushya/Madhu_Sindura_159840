package org.cap.demo;

public class Demo2DArrayPatterns {

	static int[][] array;
	
	public static void transpose() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(array[j][i]+" ");}System.out.println();}
	}
	
	public static void lowerTriangle() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(j<=i)System.out.print(array[j][i]+" ");
			}
			System.out.println();
		}
	}

	public static void upperTriangle() {
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(i<=j)System.out.print(array[i][j]+" ");
				else System.out.print("  ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		array= new int[3][3];
		int x=1;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				array[i][j]=x;x++;
				System.out.print(array[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println("\n\n");
		upperTriangle(); 
		System.out.println("\n\n");
		lowerTriangle(); 
		System.out.println("\n\n");
		transpose();
	}
	
}


