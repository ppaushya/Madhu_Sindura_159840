package org.cap.service;

import java.util.List;

import org.cap.dao.IPilotDBDao;
import org.cap.dao.IPilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("pilotDbService")
public class PilotDbServiceImpl implements IPilotService{

	@Autowired
	private IPilotDBDao pilotDbDao;
	
	@Override
	public List<Pilot> getAllPilots() {
		return pilotDbDao.findAll();
	}

	@Override
	public Pilot find(int pilotId) {
		Pilot pilot=pilotDbDao.findById(pilotId).get();
		return pilot;
	}

	@Override
	public List<Pilot> updateCustomers(Pilot pilot) {
		 pilotDbDao.save(pilot);
		 return getAllPilots();
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		Pilot pilot=find(pilotId);
		pilotDbDao.delete(pilot);
		return getAllPilots();
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		 pilotDbDao.save(pilot);
		 return getAllPilots();
	}

	@Override
	public List<Pilot> patchPilot(Pilot pilot) {
		return null;
	}


}
