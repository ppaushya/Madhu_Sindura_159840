package org.cap.controller;

import java.util.List;

import org.cap.model.Pilot;
import org.cap.service.PilotDbServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2")
public class PilotDbController {

	@Autowired
	private PilotDbServiceImpl pilotDbService;
	
	@GetMapping("/pilots")
	public ResponseEntity<List<Pilot>> getAllPilots(){
		
		List<Pilot> pilots=pilotDbService.getAllPilots();
		
		if(pilots.isEmpty())
			return new ResponseEntity("Sorry! Pilots Not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots,HttpStatus.OK);
	}
	
	@GetMapping("/pilots/{pilotId}")
	public ResponseEntity<Pilot> findPilot(@PathVariable("pilotId") Integer pilotId){
		Pilot pilot=pilotDbService.find(pilotId);
		if(pilot==null)
			return new ResponseEntity("Sorry! Pilots Not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Pilot>(pilot,HttpStatus.OK);
	}
	
	@DeleteMapping("/pilots/{pilotId}")
	public ResponseEntity<List<Pilot>>  deletePilot(@PathVariable("pilotId") Integer pilotId)
	{
		List<Pilot> pilot=pilotDbService.deletePilot(pilotId);
		if(pilot.isEmpty())
			return new ResponseEntity("Sorry! Pilots Not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilot,HttpStatus.OK);
	}
	
	@PutMapping("/pilots")
	public ResponseEntity<List<Pilot>> updatePilots(@RequestBody Pilot pilot){
		List<Pilot> pilots= pilotDbService.updateCustomers(pilot);
		System.out.println(pilots);
		if(pilots.isEmpty())
			return new ResponseEntity("insertion failed", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@PostMapping(value="/pilots")
	public ResponseEntity<List<Pilot>> createPilots(@RequestBody Pilot pilot){
		List<Pilot> pilots= pilotDbService.createPilot(pilot);
		System.out.println(pilots);
		if(pilots.isEmpty())
			return new ResponseEntity("insertion failed", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
	
	@PatchMapping(value="/pilots")
	public ResponseEntity<List<Pilot>> patchPilot(@RequestBody Pilot pilot){
		List<Pilot> pilots= pilotDbService.patchPilot(pilot);
		System.out.println(pilots);
		if(pilots.isEmpty())
			return new ResponseEntity("insertion failed", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Pilot>>(pilots, HttpStatus.OK);
	}
}
