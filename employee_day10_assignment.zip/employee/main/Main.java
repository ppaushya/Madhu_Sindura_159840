package org.capg.employee.main;


import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.capg.employee.dao.EmployeeDao;
import org.capg.employee.dao.EmployeeDaoImplementation;
import org.capg.employee.model.Employee;
import org.capg.employee.ui.UserInteraction;


public class Main {
	
	public static void main(String...args) {
		Scanner scanner=new Scanner(System.in);
		Employee employee = null;
		int employeeId =0 ;
		
		UserInteraction userInteraction=new UserInteraction();
		EmployeeDao employeeDao=new EmployeeDaoImplementation();
		
		String choice="y";
		do {
			System.out.println("Select option :");
			System.out.println("1. Insert an employee");
			System.out.println("2. Update a column");
			System.out.println("3. List all employee");
			System.out.println("4. Find an employee");
			System.out.println("5. Delete an employee");
			
			int option;
			option=scanner.nextInt();
			switch(option) {
			case 1:
				employee=userInteraction.getEmployeeDetails();
				employeeDao.insertEmployeeDetails(employee);
				break;
			case 2:
				employeeId=userInteraction.getEmployeeId();
				System.out.println("What do u want to update :");
				System.out.println("1. First Name");
				System.out.println("2. Last Name");
				System.out.println("3. Salary");
				System.out.println("4. Date of joining");
				
				option=scanner.nextInt();
				
				switch(option) {
				case 1: 
					employeeDao.updateFirstName(userInteraction.getNewName(),employeeId);
					break;
				case 2:
					employeeDao.updateLastName(userInteraction.getNewName(),employeeId);
					break;
				case 3:
					employeeDao.updateSalary(userInteraction.getNewSalary(),employeeId);
					break;
				case 4:
					employeeDao.updateDoj(userInteraction.getNewDate(),employeeId);
					break;
				default: System.out.println("Enter 1/2/3/4");
				}
				break;
			case 3:
				List<Employee> employeeList=employeeDao.printEmployeeList();
				userInteraction.printEmployeeList(employeeList);
				break;
			case 4:
				employeeId=userInteraction.getEmployeeId();
				employeeDao.printEmployeeDetails(employeeId);
				break;
			case 5:
				employeeId=userInteraction.getEmployeeId();
				employeeDao.deleteEmployeeDetails(employee,employeeId);
				break;
			default:
				System.out.println("Only 5 options!");
			}
			System.out.println("Do you want to continue?[y|n]");
			choice=scanner.next();
		}while(choice.charAt(0)=='y');
	}
}
