package org.capg.employee.dao;

import java.time.LocalDate;
import java.util.List;

import org.capg.employee.model.Employee;

public interface EmployeeDao{
	public void insertEmployeeDetails(Employee employee);
	public void printEmployeeDetails(int employeeId);
	public void deleteEmployeeDetails(Employee employee, int employeeId);
	public List<Employee> printEmployeeList();
	public void updateSalary(double salary,int employeeId);
	public void updateDoj(LocalDate doj, int employeeId);
	void updateFirstName(String name, int employeeId);
	public void updateLastName(String newName, int employeeId);
}
