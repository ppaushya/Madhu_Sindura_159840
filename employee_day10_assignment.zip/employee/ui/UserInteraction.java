package org.capg.employee.ui;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.capg.employee.model.Employee;

public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	
	public Employee getEmployeeDetails() {
		Employee employee=new Employee();
		System.out.print("Enter Employee Id:");
		employee.setEmpId(scanner.nextInt());
		
		System.out.print("Enter Employee FirstName:");
		employee.setFirstName(scanner.next());
		
		System.out.print("Enter Employee LastName:");
		employee.setLastName(scanner.next());
		
		System.out.print("Enter Employee Salary:");
		employee.setSalary(scanner.nextDouble());
		
		System.out.print("Enter Employee DateOf Joining[yyyy-mm-dd]:");
		String[] date=scanner.next().split("-");
		employee.setDoj(LocalDate.of(
				Integer.parseInt(date[0]), 
				Integer.parseInt(date[1]), 
				Integer.parseInt((date[2]))));
		
		return employee;
	}

	public int getEmployeeId() {
		System.out.println("Enter Employee Id:");
		return scanner.nextInt();
	}

	public void printEmployeeList(List<Employee> employeeList) {
		Iterator<Employee> iterator=employeeList.iterator();
		while(iterator.hasNext()) System.out.println(iterator.next());
	}

	public String getNewName() {
		System.out.println("Enter new Name:");
		return scanner.next();
	}

	public double getNewSalary() {
		System.out.println("Enter new Salary:");
		return scanner.nextDouble();
	}

	public LocalDate getNewDate() {
		System.out.print("Enter date of joining in dd/mm/yyyy format: ");
		String tempDateStr = scanner.next();
		String[] str=tempDateStr.split("/", 3);
		LocalDate tempDoB=LocalDate.of(Integer.parseInt(str[2]), Integer.parseInt(str[1]), Integer.parseInt(str[0]));
		return tempDoB;
	}

}
